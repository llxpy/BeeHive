﻿print(123)
