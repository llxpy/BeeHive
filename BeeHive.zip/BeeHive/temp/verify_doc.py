﻿from docx import Document
d=Document('C:\\Users\\30426\\Desktop\\深夜的敲门声.docx')
print('标题:',d.paragraphs[0].text)
ps=[p for p in d.paragraphs if p.text.strip()]
print('正文段落数:',len(ps))
print('第一段:',ps[1].text[:50])
print('最后一段:',ps[-1].text[:50])
