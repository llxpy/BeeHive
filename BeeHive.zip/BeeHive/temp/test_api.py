import os, sys, json, urllib.request, urllib.error, ssl

BEEHIVE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

config = {}
for p in [os.path.join(BEEHIVE_ROOT, 'config.json'), os.path.join(BEEHIVE_ROOT, 'local_config.json')]:
    if os.path.exists(p):
        with open(p, 'r', encoding='utf-8') as f:
            config.update(json.load(f))

api_config = config.get('api', {})
MODEL = api_config.get('model_name', '?')
URL = api_config.get('base_url', '').rstrip('/') + '/chat/completions'
KEY = api_config.get('api_key', '')

print(f'Model: {MODEL}')
print(f'URL: {URL}')
print(f'Key: {KEY[:10]}...')

data = json.dumps({
    'model': MODEL,
    'messages': [{'role': 'user', 'content': '用一句话回复：1+1等于几？'}],
    'temperature': 0.6,
    'presence_penalty': 0.0,
    'repetition_penalty': 1.0,
    'top_p': 0.95,
    'top_k': 20,
    'min_p': 0.0,
    'chat_template_kwargs': {'enable_thinking': True},
    'thinking': {'type': 'enabled'},
    'stream': False
}).encode('utf-8')

try:
    req = urllib.request.Request(URL, data=data, headers={
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {KEY}'
    })
    ctx = ssl.create_default_context()
    resp = urllib.request.urlopen(req, timeout=30, context=ctx)
    body = json.loads(resp.read().decode('utf-8'))
    content = body['choices'][0]['message']['content']
    print(f'Response: {content}')
except urllib.error.HTTPError as e:
    body = e.read().decode()
    print(f'HTTP {e.code}: {body[:800]}')
except Exception as e:
    print(f'Error: {type(e).__name__}: {e}')
