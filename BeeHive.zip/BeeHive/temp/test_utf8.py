print('hello')  
