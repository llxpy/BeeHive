import openpyxl  
wb = openpyxl.Workbook()  
wb.save(r'C:\Users\30426\Desktop\BeeHive\�½����ļ�.xlsx')  
print('OK') 
