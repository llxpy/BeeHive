print('OK')) 
