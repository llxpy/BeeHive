print(\"hello\")  
