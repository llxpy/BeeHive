import openpyxl  
wb=openpyxl.Workbook()  
wb.save(\"C:/Users/30426/Desktop/BeeHive/new_file.xlsx\")  
print(\"OK\") 
