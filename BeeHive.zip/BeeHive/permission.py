#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
权限模型 (Permission Model) — L0-L4 五级权限 + RSA 签名/校验 + 白名单

五级权限定义：
  L0 = "只读"      — 文件读取、系统信息查询
  L1 = "沙箱"      — ~/.beehive/sandbox 内任意操作
  L2 = "用户空间"   — 桌面/文档/下载等用户目录读写
  L3 = "系统级"     — 全磁盘访问 + 进程管理 + 注册表
  L4 = "完全接管"   — 关机/重启/网络/驱动/服务

每个操作类型映射到所需的最小权限等级。
"""

import os
import json
import time
import hashlib
import base64
from pathlib import Path
from datetime import datetime

# ---------------------------------------------------------------------------
# 项目根目录（BeeHive 所在目录）
# ---------------------------------------------------------------------------
BEEHIVE_ROOT = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
# 五级权限定义
# ---------------------------------------------------------------------------
LEVEL_L0 = "L0"  # 只读
LEVEL_L1 = "L1"  # 沙箱
LEVEL_L2 = "L2"  # 用户空间
LEVEL_L3 = "L3"  # 系统级
LEVEL_L4 = "L4"  # 完全接管

PERMISSION_LEVELS = [LEVEL_L0, LEVEL_L1, LEVEL_L2, LEVEL_L3, LEVEL_L4]

# 权限等级数值映射（用于比较大小）
LEVEL_RANK = {LEVEL_L0: 0, LEVEL_L1: 1, LEVEL_L2: 2, LEVEL_L3: 3, LEVEL_L4: 4}

# ---------------------------------------------------------------------------
# 权限中文说明
# ---------------------------------------------------------------------------
PERMISSION_DESCRIPTIONS = {
    LEVEL_L0: "只读 — 只能读取文件和查询系统信息，不能修改任何内容",
    LEVEL_L1: "沙箱 — 在 BeeHive 专属沙箱目录内可任意操作，不可访问外部文件",
    LEVEL_L2: "用户空间 — 可在桌面/文档/下载等用户目录读写文件",
    LEVEL_L3: "系统级 — 全磁盘访问 + 进程管理 + 注册表读写（HKCU）",
    LEVEL_L4: "完全接管 — 关机/重启/网络配置/驱动安装/服务管理/注册表（HKLM）",
}

# ---------------------------------------------------------------------------
# 操作类型 → 所需最小权限等级
# ---------------------------------------------------------------------------
OPERATION_PERMISSIONS = {
    # 文件操作
    "file_read": LEVEL_L0,           # 读取文件内容
    "file_list": LEVEL_L0,           # 列出目录
    "file_write_sandbox": LEVEL_L1,  # 沙箱内写入文件
    "file_write_user": LEVEL_L2,     # 用户目录写入文件
    "file_write_anywhere": LEVEL_L3, # 任意位置写入文件
    "file_delete_user": LEVEL_L2,    # 删除用户目录文件
    "file_delete_system": LEVEL_L3,  # 删除系统文件
    # 进程操作
    "process_list": LEVEL_L0,        # 列出进程
    "process_terminate": LEVEL_L3,   # 终止进程
    "process_create": LEVEL_L3,      # 创建进程
    # 注册表操作
    "registry_read": LEVEL_L0,       # 读取注册表
    "registry_write_hkcu": LEVEL_L3, # 写入 HKCU
    "registry_write_hklm": LEVEL_L4, # 写入 HKLM
    # 网络操作
    "network_query": LEVEL_L0,       # 查询网络状态
    "network_modify": LEVEL_L4,      # 修改网络配置
    # 窗口操作
    "window_query": LEVEL_L0,        # 查询窗口信息
    "window_control": LEVEL_L2,      # 控制窗口
    # 系统操作
    "system_info": LEVEL_L0,         # 系统信息查询
    "system_service": LEVEL_L4,      # 服务管理
    "system_shutdown": LEVEL_L4,     # 关机/重启
    "system_driver": LEVEL_L4,       # 驱动管理
    # 其他
    "input_simulate": LEVEL_L2,      # 输入模拟
    "scheduler_task": LEVEL_L3,      # 计划任务
}

# ---------------------------------------------------------------------------
# 用户目录路径（Windows）
# ---------------------------------------------------------------------------
def get_user_paths():
    """获取用户空间路径列表"""
    user_profile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
    return [
        os.path.join(user_profile, "Desktop"),
        os.path.join(user_profile, "Documents"),
        os.path.join(user_profile, "Downloads"),
        os.path.join(user_profile, "Pictures"),
        os.path.join(user_profile, "Videos"),
        os.path.join(user_profile, "Music"),
        user_profile,  # 用户根目录
    ]

# ---------------------------------------------------------------------------
# 沙箱路径
# ---------------------------------------------------------------------------
def get_sandbox_path():
    """获取沙箱目录路径"""
    return os.path.join(BEEHIVE_ROOT, "sandbox")

# ---------------------------------------------------------------------------
# 白名单路径生成
# ---------------------------------------------------------------------------
def generate_whitelist(level: str) -> list:
    """
    根据权限等级生成路径白名单
    :param level: 权限等级 (L0-L4)
    :return: 允许访问的路径列表
    """
    whitelist = []

    # L0+ 总是允许读取 BeeHive 自身目录
    whitelist.append(BEEHIVE_ROOT)

    if LEVEL_RANK.get(level, 0) >= LEVEL_RANK[LEVEL_L1]:
        # L1+: 沙箱目录
        whitelist.append(get_sandbox_path())

    if LEVEL_RANK.get(level, 0) >= LEVEL_RANK[LEVEL_L2]:
        # L2+: 用户空间
        whitelist.extend(get_user_paths())

    if LEVEL_RANK.get(level, 0) >= LEVEL_RANK[LEVEL_L3]:
        # L3+: 全磁盘（所有盘符根目录）
        whitelist.append("C:\\")
        # 枚举所有盘符
        import string
        for drive in string.ascii_uppercase:
            drive_path = f"{drive}:\\"
            if os.path.exists(drive_path):
                whitelist.append(drive_path)

    if LEVEL_RANK.get(level, 0) >= LEVEL_RANK[LEVEL_L4]:
        # L4: 无限制（* 通配）
        whitelist.append("*")

    return whitelist

# ---------------------------------------------------------------------------
# 权限校验
# ---------------------------------------------------------------------------
def verify_permission(operation_type: str, target_path: str = "",
                      current_level: str = LEVEL_L2) -> bool:
    """
    校验操作是否有权限执行
    :param operation_type: 操作类型（见 OPERATION_PERMISSIONS）
    :param target_path: 目标路径（可选，用于路径级校验）
    :param current_level: 当前权限等级
    :return: True 表示允许，False 表示拒绝
    """
    # 获取操作所需的最小权限等级
    required_level = OPERATION_PERMISSIONS.get(operation_type, LEVEL_L4)
    required_rank = LEVEL_RANK.get(required_level, 4)
    current_rank = LEVEL_RANK.get(current_level, 0)

    # 权限等级不足
    if current_rank < required_rank:
        return False

    # 如果有目标路径，检查是否在白名单内
    if target_path:
        whitelist = generate_whitelist(current_level)
        if "*" in whitelist:
            return True  # L4 无限制
        # 规范化路径比较
        target_norm = os.path.normpath(target_path).lower()
        for allowed in whitelist:
            allowed_norm = os.path.normpath(allowed).lower()
            if target_norm.startswith(allowed_norm):
                return True
        return False

    return True

# ---------------------------------------------------------------------------
# RSA 签名（简化实现：使用 HMAC-SHA256 替代完整 RSA）
# 说明：完整 RSA 实现依赖标准库外的数学运算，这里使用基于密钥的 HMAC 作为等效签名方案
# 签名验证同样安全——只有持有密钥的蜂后才能生成有效签名
# ---------------------------------------------------------------------------
def _get_or_create_secret():
    """获取或创建签名密钥"""
    key_file = os.path.join(BEEHIVE_ROOT, ".beehive_key")
    if os.path.exists(key_file):
        with open(key_file, "rb") as f:
            return f.read()
    # 生成新密钥（32 字节随机密钥）
    secret = os.urandom(32)
    with open(key_file, "wb") as f:
        f.write(secret)
    # 设置文件为隐藏（Windows）
    try:
        import ctypes
        ctypes.windll.kernel32.SetFileAttributesW(key_file, 2)  # FILE_ATTRIBUTE_HIDDEN
    except Exception:
        pass
    return secret

def sign_permission(permission_data: dict) -> str:
    """
    对权限数据进行签名
    :param permission_data: 权限数据字典
    :return: Base64 编码的签名字符串
    """
    secret = _get_or_create_secret()
    # 序列化为规范 JSON（排序键以保证一致性）
    canonical = json.dumps(permission_data, sort_keys=True, ensure_ascii=False)
    # HMAC-SHA256 签名
    signature = hashlib.pbkdf2_hmac(
        "sha256",
        canonical.encode("utf-8"),
        secret,
        100000,  # 迭代次数
        dklen=32
    )
    return base64.b64encode(signature).decode("ascii")

def verify_signature(permission_data: dict, signature: str) -> bool:
    """
    验证权限数据的签名
    :param permission_data: 权限数据字典
    :param signature: Base64 签名字符串
    :return: True 表示签名有效
    """
    expected = sign_permission(permission_data)
    # 使用常量时间比较防止时序攻击
    return hashlib.compare_digest(expected, signature)

# ---------------------------------------------------------------------------
# 权限文件管理
# ---------------------------------------------------------------------------
def create_signed_permission(level: str, allowed_paths: list = None) -> dict:
    """
    创建签名后的权限文件内容
    :param level: 权限等级
    :param allowed_paths: 自定义允许路径
    :return: 权限数据字典
    """
    if level not in PERMISSION_LEVELS:
        raise ValueError(f"无效的权限等级: {level}，必须是 {PERMISSION_LEVELS} 之一")

    data = {
        "level": level,
        "timestamp": datetime.now().isoformat(),
        "allowed_paths": allowed_paths or generate_whitelist(level),
    }
    data["signature"] = sign_permission(data)
    return data

def save_signed_permission(filepath: str, level: str, allowed_paths: list = None):
    """
    保存签名权限文件
    :param filepath: 输出文件路径
    :param level: 权限等级
    :param allowed_paths: 自定义允许路径
    """
    data = create_signed_permission(level, allowed_paths)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return data

def load_signed_permission(filepath: str) -> dict:
    """
    加载并验证签名权限文件
    :param filepath: 权限文件路径
    :return: 权限数据字典，验证失败抛出 ValueError
    """
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    signature = data.pop("signature", "")
    if not signature:
        raise ValueError("权限文件缺少签名")

    if not verify_signature(data, signature):
        raise ValueError("权限签名验证失败！文件可能被篡改")

    data["signature"] = signature  # 恢复签名字段
    return data

# ---------------------------------------------------------------------------
# 检查某个路径是否在给定权限下允许访问
# ---------------------------------------------------------------------------
def is_path_allowed(target_path: str, permission_data: dict, operation: str = "file_read") -> bool:
    """
    检查路径是否被允许访问
    :param target_path: 目标路径
    :param permission_data: 权限数据字典
    :param operation: 操作类型
    :return: True 允许访问
    """
    level = permission_data.get("level", LEVEL_L0)
    allowed_paths = permission_data.get("allowed_paths", [])

    # 先检查操作权限等级
    if not verify_permission(operation, "", level):
        return False

    # L4 无限制
    if "*" in allowed_paths or level == LEVEL_L4:
        return True

    # 路径白名单检查
    target_norm = os.path.normpath(target_path).lower()
    for allowed in allowed_paths:
        allowed_norm = os.path.normpath(allowed).lower()
        if target_norm.startswith(allowed_norm):
            return True

    return False

# ---------------------------------------------------------------------------
# 自检
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("=== Permission Model 测试 ===\n")

    # 测试权限等级比较
    print(f"L2 是否可以执行 file_read: {verify_permission('file_read', '', LEVEL_L2)}")
    print(f"L2 是否可以执行 process_terminate: {verify_permission('process_terminate', '', LEVEL_L2)}")
    print(f"L4 是否可以执行 system_shutdown: {verify_permission('system_shutdown', '', LEVEL_L4)}")

    # 测试路径白名单
    sys_root = "C:\\Windows"
    print(f"\nL2 访问桌面: {verify_permission('file_write_user', os.path.expanduser('~/Desktop'))}")
    print(f"L2 访问 {sys_root}: {verify_permission('file_write_user', sys_root)}")

    # 测试签名
    test_data = create_signed_permission(LEVEL_L3)
    print(f"\n签名权限数据: {json.dumps(test_data, ensure_ascii=False, indent=2)}")
    print(f"签名验证: {verify_signature({k:v for k,v in test_data.items() if k!='signature'}, test_data['signature'])}")

