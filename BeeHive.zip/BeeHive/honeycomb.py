#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
蜜脾 (Honeycomb) — 中文结构化日志系统

功能：
- 日志目录结构：logs/{YYYY-MM-DD}/
- 每只蜂独立日志文件
- 每日索引文件 index.json
- 中文格式日志：[时间] [角色-ID] [操作类型] 描述 | 耗时 Xs | 结果
- 日志轮转：保留最近 30 天
- 自身异常保护：写日志崩溃不影响主流程
"""

import os
import json
import time
import threading
from datetime import datetime, timedelta
from pathlib import Path

# ---------------------------------------------------------------------------
# 日志根目录（相对于 beehive.py 所在目录）
# ---------------------------------------------------------------------------
LOG_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")

# ---------------------------------------------------------------------------
# 操作类型枚举
# ---------------------------------------------------------------------------
class OpType:
    """操作类型枚举"""
    FILE_OP = "文件操作"           # 文件创建/读取/写入/删除/移动
    PROCESS_OP = "进程操作"        # 进程启动/终止/查询
    REGISTRY_OP = "注册表操作"      # 注册表读写
    NETWORK_OP = "网络操作"         # DNS/代理/防火墙
    WINDOW_OP = "窗口操作"          # 窗口管理
    SYSTEM_SETTING = "系统设置"     # 服务/计划任务/开机自启
    ANOMALY_DETECT = "异常检测"     # 守卫蜂检测到异常
    KILL_WORKER = "终止工蜂"        # 守卫蜂 kill 工蜂
    QUEEN_OP = "蜂后操作"           # 蜂后调度决策
    GUARD_OP = "守卫操作"           # 守卫蜂监控
    WORKER_OP = "工蜂操作"          # 工蜂执行

# ---------------------------------------------------------------------------
# 颜色定义（ANSI 转义码）
# ---------------------------------------------------------------------------
class Colors:
    """不同角色的日志颜色"""
    RESET = "\033[0m"
    QUEEN = "\033[1;35m"     # 亮紫色 — 蜂后
    GUARD = "\033[1;31m"     # 亮红色 — 守卫蜂
    WORKER = "\033[1;33m"    # 亮黄色 — 工蜂
    HIVE = "\033[1;36m"      # 亮青色 — 蜂巢
    INFO = "\033[1;37m"      # 亮白色 — 一般信息
    WARN = "\033[1;33m"      # 黄色 — 警告
    ERROR = "\033[1;31m"     # 红色 — 错误
    SUCCESS = "\033[1;32m"   # 绿色 — 成功
    DIM = "\033[2m"          # 暗色 — 次要信息

# ---------------------------------------------------------------------------
# 日志核心类
# ---------------------------------------------------------------------------
class Honeycomb:
    """
    蜜脾日志系统
    线程安全，自身异常不影响主流程
    """

    # 角色颜色映射
    ROLE_COLORS = {
        "queen": Colors.QUEEN,
        "guard": Colors.GUARD,
        "worker": Colors.WORKER,
        "hive": Colors.HIVE,
    }

    def __init__(self, role: str, bee_id: str = ""):
        """
        初始化日志实例
        :param role: 角色名 (queen/guard/worker/hive)
        :param bee_id: 蜂的标识符（如 worker_001）
        """
        self.role = role
        self.bee_id = bee_id or f"{role}_{os.getpid()}"
        self._lock = threading.Lock()
        self._today = datetime.now().strftime("%Y-%m-%d")
        self._log_dir = os.path.join(LOG_ROOT, self._today)
        self._log_file = os.path.join(self._log_dir, f"{role}.log")
        self._index_file = os.path.join(self._log_dir, "index.json")
        self._ensure_dirs()

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------
    def _ensure_dirs(self):
        """确保日志目录存在"""
        try:
            os.makedirs(self._log_dir, exist_ok=True)
        except Exception:
            pass  # 目录创建失败不阻塞主流程

    def _check_date_roll(self):
        """检查是否需要日期轮转"""
        today = datetime.now().strftime("%Y-%m-%d")
        if today != self._today:
            self._today = today
            self._log_dir = os.path.join(LOG_ROOT, self._today)
            self._log_file = os.path.join(self._log_dir, f"{self.role}.log")
            self._index_file = os.path.join(self._log_dir, "index.json")
            self._ensure_dirs()

    def _format_message(
        self,
        op_type: str,
        description: str,
        duration: float = 0.0,
        result: str = "",
        extra: dict = None
    ) -> str:
        """
        格式化中文日志消息
        格式: [时间] [角色-ID] [操作类型] 描述 | 耗时 Xs | 结果
        """
        now = datetime.now().strftime("%H:%M:%S.%f")[:-3]  # 精确到毫秒
        parts = [
            f"[{now}]",
            f"[{self.role}-{self.bee_id}]",
            f"[{op_type}]",
            description,
        ]
        if duration > 0:
            parts.append(f"| 耗时 {duration:.2f}s")
        if result:
            parts.append(f"| {result}")
        if extra:
            # 附加信息用紧凑 JSON
            parts.append(f"| {json.dumps(extra, ensure_ascii=False)}")
        return " ".join(parts)

    # ------------------------------------------------------------------
    # 写日志（线程安全，自身异常保护）
    # ------------------------------------------------------------------
    def _write_log(self, message: str):
        """写入日志文件，线程安全"""
        try:
            self._check_date_roll()
            with self._lock:
                with open(self._log_file, "a", encoding="utf-8") as f:
                    f.write(message + "\n")
        except Exception:
            pass  # 日志写失败静默处理，不影响主流程

    def log(
        self,
        op_type: str,
        description: str,
        duration: float = 0.0,
        result: str = "",
        extra: dict = None
    ):
        """
        写中文日志
        :param op_type: 操作类型（使用 OpType 枚举）
        :param description: 中文描述
        :param duration: 耗时（秒）
        :param result: 结果摘要
        :param extra: 附加信息字典
        """
        try:
            message = self._format_message(op_type, description, duration, result, extra)
            self._write_log(message)
        except Exception:
            pass  # 自身异常不阻塞

    def log_with_color(
        self,
        op_type: str,
        description: str,
        duration: float = 0.0,
        result: str = "",
        extra: dict = None
    ):
        """写日志并输出到控制台（带颜色）"""
        self.log(op_type, description, duration, result, extra)
        # 控制台带颜色输出
        color = self.ROLE_COLORS.get(self.role, Colors.INFO)
        try:
            message = self._format_message(op_type, description, duration, result, extra)
            print(f"{color}{message}{Colors.RESET}")
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 快捷方法
    # ------------------------------------------------------------------
    def info(self, description: str, **kwargs):
        """信息日志"""
        self.log(OpType.QUEEN_OP if self.role == "queen" else
                 OpType.GUARD_OP if self.role == "guard" else
                 OpType.WORKER_OP, description, **kwargs)

    def warn(self, description: str, **kwargs):
        """警告日志（同时输出到控制台）"""
        self.log_with_color(OpType.ANOMALY_DETECT, f"[警告] {description}", **kwargs)

    def error(self, description: str, **kwargs):
        """错误日志（同时输出到控制台）"""
        self.log_with_color(OpType.ANOMALY_DETECT, f"[错误] {description}", **kwargs)

    def success(self, description: str, **kwargs):
        """成功日志（同时输出到控制台）"""
        self.log_with_color(OpType.QUEEN_OP, f"[成功] {description}", **kwargs)

    # ------------------------------------------------------------------
    # 索引管理
    # ------------------------------------------------------------------
    def update_index(self, total_ops: int = 1, risk_events: list = None,
                     killed_workers: list = None):
        """更新每日索引文件"""
        try:
            self._check_date_roll()
            # 读取现有索引
            index_data = {"date": self._today, "total_operations": 0,
                          "risk_events": [], "killed_workers": []}
            try:
                with open(self._index_file, "r", encoding="utf-8") as f:
                    existing = json.load(f)
                    index_data["total_operations"] = existing.get("total_operations", 0)
                    index_data["risk_events"] = existing.get("risk_events", [])
                    index_data["killed_workers"] = existing.get("killed_workers", [])
            except (FileNotFoundError, json.JSONDecodeError):
                pass

            # 更新数据
            index_data["total_operations"] += total_ops
            if risk_events:
                index_data["risk_events"].extend(risk_events)
            if killed_workers:
                index_data["killed_workers"].extend(killed_workers)

            # 写入
            with open(self._index_file, "w", encoding="utf-8") as f:
                json.dump(index_data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 日志轮转（清理超过 30 天的目录）
    # ------------------------------------------------------------------
    @staticmethod
    def rotate_logs():
        """清理超过 30 天的日志目录"""
        try:
            cutoff = datetime.now() - timedelta(days=30)
            if not os.path.isdir(LOG_ROOT):
                return
            for entry in os.listdir(LOG_ROOT):
                entry_path = os.path.join(LOG_ROOT, entry)
                if not os.path.isdir(entry_path):
                    continue
                # 尝试解析目录名为日期
                try:
                    dir_date = datetime.strptime(entry, "%Y-%m-%d")
                    if dir_date < cutoff:
                        import shutil
                        shutil.rmtree(entry_path, ignore_errors=True)
                except ValueError:
                    continue  # 非日期目录跳过
        except Exception:
            pass

# ---------------------------------------------------------------------------
# 全局工厂函数
# ---------------------------------------------------------------------------
def create_logger(role: str, bee_id: str = "") -> Honeycomb:
    """创建日志记录器"""
    return Honeycomb(role, bee_id)

