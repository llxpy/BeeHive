---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: e9a6114d085f74827089176c633e5d7f_1bca97045f2811f1a4f35254002afed2
    ReservedCode1: cpOjtjH5CbzDmJ6SsLtfrVfnoX9AehrWg6OyYfFKybxqo7bUiucEAj2KS2yM8PfEdW/I1N3G2NytThwb+yiOvYmeSK83WCbUkBQkvgpzceQZF+to55pXEdQrYhTz0ZCPGZoRzYAdk3L3iGHX862L7z0rb7VwQhlqRyYukpNFWyB+/eyAS2aw0qqMrI0=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: e9a6114d085f74827089176c633e5d7f_1bca97045f2811f1a4f35254002afed2
    ReservedCode2: cpOjtjH5CbzDmJ6SsLtfrVfnoX9AehrWg6OyYfFKybxqo7bUiucEAj2KS2yM8PfEdW/I1N3G2NytThwb+yiOvYmeSK83WCbUkBQkvgpzceQZF+to55pXEdQrYhTz0ZCPGZoRzYAdk3L3iGHX862L7z0rb7VwQhlqRyYukpNFWyB+/eyAS2aw0qqMrI0=
---

# BeeHive 蜂巢知识库 (Hive Knowledge)

> 固化技能、规则与经验。由蜂后在任务执行过程中自动写入和更新。
> 类比 AntNest 的 NEST.md。

---

## 系统信息

- 操作系统: Windows 11
- 项目路径: C:\Users\30426\Desktop\BeeHive
- Python 版本: 3.8+

---

## 固化规则

1. **安全第一**: 所有系统级操作前必须校验权限等级，L3+ 方可操作注册表和进程。
2. **工蜂隔离**: 每只工蜂在独立 clone_pool 目录中执行，执行完毕立即销毁。
3. **深度硬限制**: depth >= 3 时禁止再次 spawn，降级为直接执行。
4. **守卫蜂独立**: 守卫蜂的 kill 决策为纯规则引擎，不经过 LLM。

---

## 常用技能模板

### 文件整理
- 触发条件: 用户要求整理桌面/文件夹
- 做法: 按文件类型分类到子目录（文档/图片/视频/压缩包/其他）

### 系统信息查询
- 触发条件: 用户询问系统状态
- 做法: 收集 CPU/内存/磁盘/进程信息并格式化输出

---

## 已知问题与注意事项

- Worker 在 clone_pool 中执行，工作目录限制在权限白名单内
- 长命令（>8000 字符）自动使用临时文件传递
- 守卫蜂监控 CPU/内存/文件访问/网络连接

