---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: e9a6114d085f74827089176c633e5d7f_1c4700ca5f2811f1a4f35254002afed2
    ReservedCode1: Hy0HchvTK/L133XzSSqOsqAC/Ict9As1XSEVvBD+giaQEK5364pAtJTprGp1IhDh9Bz0tvsRpnTrvdIT0xdq1C9ECfCDDbct0qhkFrBsdDijDJKS5cA3wJ09f5YwME9se+dRx2AlZsH9O8zIdCRmz1+pdeZU2+mBjHwBJpXdnQ6sm60/xGDqRQxEIQg=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: e9a6114d085f74827089176c633e5d7f_1c4700ca5f2811f1a4f35254002afed2
    ReservedCode2: Hy0HchvTK/L133XzSSqOsqAC/Ict9As1XSEVvBD+giaQEK5364pAtJTprGp1IhDh9Bz0tvsRpnTrvdIT0xdq1C9ECfCDDbct0qhkFrBsdDijDJKS5cA3wJ09f5YwME9se+dRx2AlZsH9O8zIdCRmz1+pdeZU2+mBjHwBJpXdnQ6sm60/xGDqRQxEIQg=
---

# BeeHive 记忆线索 (Memory Hints)

> 索引和关键词，帮助蜂后在记忆压缩后快速回忆关键信息。
> 当对话历史被清空后，hints 会注入新的 system prompt。

## 最近活动

- 项目初始化: 2026-06-03

## 关键词索引

- 桌面整理: 见 hive_knowledge.md → 文件整理
- 系统监控: 见 hive_knowledge.md → 系统信息查询
- 权限管理: 五级权限 L0-L4，见 permission.py
- 工蜂管理: spawn/destroy 机制，见 queen.py

## 记忆压缩记录

（暂无）

