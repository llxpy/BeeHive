#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
守卫蜂 (Guard) — 监控所有工蜂，异常时 kill 并通知蜂后

功能：
- 独立进程运行，与蜂后通过 IPC（本地 socket 或共享文件）通信
- 注册中心：维护所有活跃工蜂的（PID, 工作目录, 权限白名单, 启动时间）
- 监控指标：
    a. CPU 使用率异常（持续 >80% 超过 10 秒）→ kill
    b. 内存使用异常（超过 500MB 且持续增长）→ kill
    c. 文件访问越权（通过监控工作目录外的文件操作）→ kill
    d. 执行超时（超过预设 timeout 的 2x）→ kill
    e. 网络连接可疑（连接非白名单 IP）→ kill
- Kill 流程：SIGTERM → 等 3 秒 → SIGKILL → rmtree 工作目录 → 写入 guard.log → 通知蜂后
- 自身心跳：每 5 秒向蜂后汇报存活状态
- 中文日志写入 guard.log：每条包含时间/工蜂ID/异常类型/处理动作

通信方式（简化版）：
- 使用共享文件（clone_pool/guard_heartbeat.json）作为蜂后通信通道
- 蜂后写入 worker_registry.json 注册工蜂
- 守卫蜂读取注册表，监控，写入 kill_events.json 通知蜂后
"""

import os
import sys
import time
import json
import signal
import threading
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------
BEEHIVE_ROOT = os.path.dirname(os.path.abspath(__file__))
CLONE_POOL_DIR = os.path.join(BEEHIVE_ROOT, "clone_pool")
LOG_DIR = os.path.join(BEEHIVE_ROOT, "logs")
GUARD_LOG = os.path.join(LOG_DIR, datetime.now().strftime("%Y-%m-%d"), "guard.log")

# 监控阈值（可通过 config.json 覆盖）
CPU_THRESHOLD = 80          # CPU 使用率阈值（%）
CPU_DURATION = 10           # CPU 持续超阈值时间（秒）
MEMORY_THRESHOLD_MB = 500   # 内存阈值（MB）
TIMEOUT_MULTIPLIER = 2.0   # 超时倍数（timeout * 2）
NETWORK_CHECK = False        # 网络连接检查（默认关闭，需要管理员权限）

# 心跳间隔
HEARTBEAT_INTERVAL = 5      # 秒
KILL_GRACE_SECONDS = 3      # SIGTERM 等待时间

# ---------------------------------------------------------------------------
# 颜色定义
# ---------------------------------------------------------------------------
class Colors:
    RESET = "\033[0m"
    GUARD = "\033[1;31m"
    WARN = "\033[1;33m"
    SUCCESS = "\033[1;32m"
    ERROR = "\033[1;31m"

# ---------------------------------------------------------------------------
# 日志
# ---------------------------------------------------------------------------
def write_guard_log(message: str, level: str = "INFO"):
    """
    写守卫蜂日志
    :param message: 日志内容
    :param level: 日志级别（INFO/WARN/ERROR/KILL）
    """
    try:
        os.makedirs(os.path.dirname(GUARD_LOG), exist_ok=True)
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        with open(GUARD_LOG, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] [{level}] {message}\n")
    except Exception:
        pass  # 日志失败不影响主流程

def log_guard(message: str, level: str = "INFO", color: str = None):
    """写日志并输出到控制台（带颜色）"""
    write_guard_log(message, level)
    c = color or (Colors.GUARD if level == "INFO" else
                  Colors.WARN if level == "WARN" else
                  Colors.ERROR if level == "ERROR" else
                  Colors.GUARD)
    print(f"{c}[守卫蜂] {message}{Colors.RESET}")

# ---------------------------------------------------------------------------
# 工蜂注册表管理
# ---------------------------------------------------------------------------
WORKER_REGISTRY_FILE = os.path.join(CLONE_POOL_DIR, "worker_registry.json")
REGISTRY_LOCK = os.path.join(CLONE_POOL_DIR, "registry.lock")
KILL_EVENTS_FILE = os.path.join(CLONE_POOL_DIR, "kill_events.json")

def _with_lock(fn):
    """文件锁上下文"""
    import msvcrt
    with open(REGISTRY_LOCK, "w") as lf:
        msvcrt.locking(lf.fileno(), msvcrt.LK_LOCK, 1)
        try:
            return fn()
        finally:
            msvcrt.locking(lf.fileno(), msvcrt.LK_UNLCK, 1)

def load_worker_registry() -> dict:
    """加载工蜂注册表（带文件锁）"""
    def _load():
        try:
            with open(WORKER_REGISTRY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    try:
        return _with_lock(_load)
    except Exception:
        return {}

def save_worker_registry(registry: dict):
    """保存工蜂注册表（带文件锁）"""
    def _save():
        os.makedirs(os.path.dirname(WORKER_REGISTRY_FILE), exist_ok=True)
        tmpfile = os.path.join(CLONE_POOL_DIR, "worker_registry.tmp")
        with open(tmpfile, "w", encoding="utf-8") as f:
            json.dump(registry, f, ensure_ascii=False, indent=2)
        os.replace(tmpfile, WORKER_REGISTRY_FILE)
    try:
        _with_lock(_save)
    except Exception:
        pass

def load_kill_events() -> list:
    """加载 kill 事件列表"""
    try:
        with open(KILL_EVENTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_kill_events(events: list):
    """保存 kill 事件"""
    try:
        os.makedirs(os.path.dirname(KILL_EVENTS_FILE), exist_ok=True)
        with open(KILL_EVENTS_FILE, "w", encoding="utf-8") as f:
            json.dump(events, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

# ---------------------------------------------------------------------------
# 进程监控工具函数
# ---------------------------------------------------------------------------
def get_process_cpu(pid: int) -> float:
    """
    获取进程 CPU 使用率（百分比）
    使用 PowerShell Get-Counter 获取精确 CPU 使用率
    """
    try:
        result = subprocess.run([
            "powershell", "-Command",
            f"$proc = Get-Counter -Counter '\\Process(*)\\% Processor Time' -EA SilentlyContinue | "
            f"Select-Object -ExpandProperty CounterSamples | "
            f"Where-Object {{ $_.InstanceName -eq (Get-Process -Id {pid} -EA SilentlyContinue).Name }} | "
            f"Select-Object -First 1 -ExpandProperty CookedValue; "
            f"if (-not $proc) {{ 0 }}"
        ], capture_output=True, text=True, timeout=10)
        val = result.stdout.strip()
        return float(val) if val else 0.0
    except Exception:
        return 0.0

def get_process_memory_mb(pid: int) -> float:
    """获取进程内存使用量（MB）"""
    try:
        result = subprocess.run([
            "powershell", "-Command",
            f"(Get-Process -Id {pid} -EA SilentlyContinue | "
            f"Select-Object -ExpandProperty WorkingSet) / 1MB"
        ], capture_output=True, text=True, timeout=10)
        val = result.stdout.strip()
        return float(val) if val else 0.0
    except Exception:
        return 0.0

def is_process_alive(pid: int) -> bool:
    """检查进程是否存活"""
    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
            capture_output=True, text=True, timeout=5
        )
        return str(pid) in result.stdout
    except Exception:
        return False

def kill_process(pid: int, grace_seconds: int = KILL_GRACE_SECONDS) -> bool:
    """
    Kill 进程：SIGTERM → 等待 → SIGKILL
    :param pid: 进程 ID
    :param grace_seconds: SIGTERM 等待时间
    :return: True 成功
    """
    try:
        # SIGTERM（taskkill /PID）
        subprocess.run(["taskkill", "/PID", str(pid), "/T"],  # /T 终止子进程
                       capture_output=True, timeout=grace_seconds + 2)

        # 等待 grace_seconds
        for _ in range(grace_seconds * 10):
            if not is_process_alive(pid):
                return True
            time.sleep(0.1)

        # SIGKILL（taskkill /F）
        log_guard(f"进程 {pid} 未响应 SIGTERM，发送 SIGKILL", "KILL")
        subprocess.run(["taskkill", "/F", "/PID", str(pid), "/T"],
                       capture_output=True, timeout=5)
        time.sleep(0.5)
        return not is_process_alive(pid)
    except Exception as e:
        log_guard(f"Kill 进程 {pid} 异常: {e}", "ERROR")
        return False

# ---------------------------------------------------------------------------
# 异常检测
# ---------------------------------------------------------------------------
class AnomalyDetector:
    """异常检测器"""

    def __init__(self):
        self.cpu_history = {}      # {pid: [timestamp, cpu_percent]}
        self.mem_history = {}      # {pid: [timestamp, mem_mb]}
        self.start_times = {}      # {pid: start_timestamp}

    def check_cpu(self, pid: int, cpu_percent: float) -> bool:
        """
        检查 CPU 异常
        持续 >80% 超过 10 秒 → 返回 True
        """
        now = time.time()
        if pid not in self.cpu_history:
            self.cpu_history[pid] = []

        history = self.cpu_history[pid]
        history.append((now, cpu_percent))

        # 只保留最近 60 秒的数据
        history[:] = [(t, c) for t, c in history if now - t <= 60]

        # 检查最近 10 秒是否持续超阈值
        recent = [(t, c) for t, c in history if now - t <= CPU_DURATION]
        if len(recent) >= 3 and all(c > CPU_THRESHOLD for _, c in recent):
            return True
        return False

    def check_memory(self, pid: int, mem_mb: float) -> bool:
        """
        检查内存异常
        超过 500MB 且持续增长 → 返回 True
        """
        now = time.time()
        if pid not in self.mem_history:
            self.mem_history[pid] = []

        history = self.mem_history[pid]
        history.append((now, mem_mb))

        # 只保留最近 60 秒
        history[:] = [(t, m) for t, m in history if now - t <= 60]

        # 检查是否超过阈值且持续增长
        if mem_mb > MEMORY_THRESHOLD_MB and len(history) >= 3:
            # 取最近 3 个采样点，检查是否持续增长
            recent = history[-3:]
            if all(recent[i][1] <= recent[i+1][1] for i in range(len(recent)-1)):
                return True
        return False

    def check_timeout(self, pid: int, timeout: float) -> bool:
        """
        检查执行超时
        超过预设 timeout 的 2x → 返回 True
        """
        if pid not in self.start_times:
            self.start_times[pid] = time.time()

        elapsed = time.time() - self.start_times[pid]
        return elapsed > (timeout * TIMEOUT_MULTIPLIER)

    def check_file_access(self, pid: int, work_dir: str) -> bool:
        """
        检查文件访问越权
        通过检查进程打开的文件句柄是否在工作目录外
        简化版：检查进程的工作目录是否被修改
        """
        try:
            # 获取进程当前工作目录
            result = subprocess.run([
                "powershell", "-Command",
                f"(Get-Process -Id {pid} -EA SilentlyContinue | "
                f"Select-Object -ExpandProperty Path)"
            ], capture_output=True, text=True, timeout=5)
            proc_path = result.stdout.strip()

            if proc_path and work_dir:
                work_norm = os.path.normpath(work_dir).lower()
                proc_norm = os.path.normpath(os.path.dirname(proc_path)).lower()
                if not proc_norm.startswith(work_norm):
                    return True
        except Exception:
            pass
        return False

    def check_network(self, pid: int) -> bool:
        """
        检查网络连接可疑
        连接非白名单 IP → 返回 True
        白名单：127.0.0.1, 0.0.0.0, 局域网段（192.168.*, 10.*）
        """
        if not NETWORK_CHECK:
            return False  # 默认关闭

        try:
            result = subprocess.run([
                "netstat", "-ano"
            ], capture_output=True, text=True, timeout=5)

            whitelist = ["127.0.0.1", "0.0.0.0", "192.168.", "10."]
            for line in result.stdout.splitlines():
                if f"TCP    {pid}" in line or f"UDP    {pid}" in line:
                    # 解析远程地址
                    parts = line.split()
                    if len(parts) >= 3:
                        remote = parts[2]
                        ip = remote.split(":")[0]
                        if not any(ip.startswith(w) for w in whitelist):
                            return True
        except Exception:
            pass
        return False

# ---------------------------------------------------------------------------
# 守卫蜂主类
# ---------------------------------------------------------------------------
class GuardBee:
    """守卫蜂"""

    def __init__(self):
        self.detector = AnomalyDetector()
        self.registry = {}
        self.running = True
        self.queen_pid = None

        # 加载配置
        self._load_config()

        log_guard("守卫蜂启动", "INFO")
        write_guard_log(f"CPU阈值={CPU_THRESHOLD}%, 内存阈值={MEMORY_THRESHOLD_MB}MB, "
                        f"超时倍数={TIMEOUT_MULTIPLIER}x", "INFO")

    def _load_config(self):
        """从 config.json 加载配置"""
        config_path = os.path.join(BEEHIVE_ROOT, "config.json")
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            global CPU_THRESHOLD, MEMORY_THRESHOLD_MB, TIMEOUT_MULTIPLIER
            CPU_THRESHOLD = config.get("security", {}).get("cpu_threshold", CPU_THRESHOLD)
            MEMORY_THRESHOLD_MB = config.get("security", {}).get("memory_threshold_mb", MEMORY_THRESHOLD_MB)
            TIMEOUT_MULTIPLIER = config.get("agent", {}).get("timeout_multiplier", TIMEOUT_MULTIPLIER)
        except Exception:
            pass

    def register_queen(self, pid: int):
        """注册蜂后 PID"""
        self.queen_pid = pid
        log_guard(f"蜂后 PID={pid} 已注册", "INFO")

    def scan_workers(self):
        """扫描并加载工蜂注册表"""
        try:
            self.registry = load_worker_registry()
            if self.registry:
                pids = [str(info.get("pid", "?")) for info in self.registry.values()]
                log_guard(f"扫描到 {len(self.registry)} 个活跃工蜂: PIDs={pids}", "INFO")
        except Exception as e:
            log_guard(f"扫描工蜂注册表异常: {e}", "ERROR")
            self.registry = {}
        return self.registry

    def monitor_once(self):
        """
        单次监控检查
        遍历所有注册工蜂，检测异常，触发 kill
        """
        registry = self.scan_workers()
        if not registry:
            return

        for worker_id, info in registry.items():
            pid = info.get("pid")
            work_dir = info.get("work_dir", "")
            timeout = info.get("timeout", 300)
            permission_level = info.get("permission_level", "L2")

            if not pid or not is_process_alive(pid):
                continue  # 进程已退出，跳过

            # --- CPU 检查 ---
            cpu = get_process_cpu(pid)
            if self.detector.check_cpu(pid, cpu):
                self._kill_worker(worker_id, info, "CPU使用率持续超阈值")
                continue

            # --- 内存检查 ---
            mem_mb = get_process_memory_mb(pid)
            if self.detector.check_memory(pid, mem_mb):
                self._kill_worker(worker_id, info, f"内存使用异常（{mem_mb:.1f}MB 且持续增长）")
                continue

            # --- 超时检查 ---
            if self.detector.check_timeout(pid, timeout):
                self._kill_worker(worker_id, info, f"执行超时（>{timeout * TIMEOUT_MULTIPLIER}s）")
                continue

            # --- 文件访问检查 ---
            if self.detector.check_file_access(pid, work_dir):
                self._kill_worker(worker_id, info, "文件访问越权")
                continue

            # --- 网络检查 ---
            if self.detector.check_network(pid):
                self._kill_worker(worker_id, info, "网络连接可疑")
                continue

    def _kill_worker(self, worker_id: str, info: dict, reason: str):
        """
        Kill 工蜂的完整流程
        1. SIGTERM → 等 3 秒 → SIGKILL
        2. rmtree 工作目录
        3. 写入 guard.log
        4. 通知蜂后（写入 kill_events.json）
        """
        pid = info.get("pid")
        work_dir = info.get("work_dir", "")

        log_guard(f"Kill 工蜂 {worker_id} (PID={pid}): {reason}", "KILL")

        # Step 1: Kill 进程
        success = kill_process(pid)
        log_guard(f"Kill 结果: {'成功' if success else '失败'}", "KILL" if success else "ERROR")

        # Step 2: 清理工作目录
        if work_dir and os.path.exists(work_dir):
            try:
                import shutil
                shutil.rmtree(work_dir, ignore_errors=True)
                log_guard(f"清理工作目录: {work_dir}", "INFO")
            except Exception as e:
                log_guard(f"清理工作目录失败: {e}", "ERROR")

        # Step 3: 通知蜂后
        self._notify_queen(worker_id, pid, reason, info)

        # Step 4: 从注册表移除
        registry = load_worker_registry()
        if worker_id in registry:
            del registry[worker_id]
            save_worker_registry(registry)

    def _notify_queen(self, worker_id: str, pid: int, reason: str, info: dict):
        """通知蜂后：工蜂被 kill"""
        event = {
            "timestamp": datetime.now().isoformat(),
            "worker_id": worker_id,
            "pid": pid,
            "reason": reason,
            "info": info,
        }
        events = load_kill_events()
        events.append(event)
        save_kill_events(events)
        log_guard(f"已通知蜂后: {json.dumps(event, ensure_ascii=False)[:200]}", "INFO")

    def send_heartbeat(self):
        """发送心跳到蜂后"""
        if not self.queen_pid or not is_process_alive(self.queen_pid):
            return

        heartbeat_file = os.path.join(CLONE_POOL_DIR, "guard_heartbeat.json")
        try:
            data = {
                "timestamp": datetime.now().isoformat(),
                "guard_pid": os.getpid(),
                "alive": True,
                "active_workers": len(self.registry),
            }
            with open(heartbeat_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
        except Exception:
            pass

    def run(self):
        """守卫蜂主循环"""
        log_guard("进入监控循环", "INFO")

        last_heartbeat = 0
        while self.running:
            try:
                # 监控检查
                self.monitor_once()

                # 心跳（每 5 秒）
                now = time.time()
                if now - last_heartbeat >= HEARTBEAT_INTERVAL:
                    self.send_heartbeat()
                    last_heartbeat = now

                time.sleep(1)  # 每秒检查一次
            except KeyboardInterrupt:
                log_guard("收到中断信号，退出", "INFO")
                self.running = False
            except Exception as e:
                log_guard(f"监控循环异常: {e}", "ERROR")
                time.sleep(5)

        log_guard("守卫蜂已停止", "INFO")

# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print(f"{Colors.GUARD}=== 守卫蜂 (Guard Bee) ==={Colors.RESET}\n")

    guard = GuardBee()

    # 如果命令行传入了蜂后 PID，则注册
    if len(sys.argv) > 1:
        try:
            queen_pid = int(sys.argv[1])
            guard.register_queen(queen_pid)
        except ValueError:
            pass

    # 启动监控循环
    guard.run()
