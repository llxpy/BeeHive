#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
蜂巢 (Hive) — Windows 系统接管层

纯 Windows 实现，使用 ctypes 调用 Win32 API 实现：
- 窗口管理：EnumWindows / GetWindowText / SetWindowPos / ShowWindow
- 输入模拟：SendInput / keybd_event / mouse_event
- 进程管理：CreateToolhelp32Snapshot / OpenProcess / TerminateProcess
- 文件系统监控：ReadDirectoryChangesW
- 注册表：RegOpenKeyEx / RegSetValueEx / RegQueryValueEx
- 服务管理：OpenSCManager / ControlService / StartService
- 网络：DNS / hosts / 代理 / 防火墙规则
- 计划任务 + 开机自启
- 蜂后守护：崩溃自动重启

所有系统操作前检查权限等级。
"""

import os
import sys
import ctypes
import struct
import time
import subprocess
import tempfile
from ctypes import wintypes
from pathlib import Path

# ---------------------------------------------------------------------------
# Win32 API 常量定义
# ---------------------------------------------------------------------------

# 窗口常量
SW_HIDE = 0
SW_SHOW = 5
SW_MINIMIZE = 6
SW_RESTORE = 9
HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_SHOWWINDOW = 0x0040

# 进程访问权限
PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010
PROCESS_ALL_ACCESS = 0x1F0FFF

# 快照标志
TH32CS_SNAPPROCESS = 0x00000002

# 输入类型
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
INPUT_HARDWARE = 2

# 键盘事件
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001

# 鼠标事件
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000

# 注册表访问权限
HKEY_CLASSES_ROOT = 0x80000000
HKEY_CURRENT_USER = 0x80000001
HKEY_LOCAL_MACHINE = 0x80000002
HKEY_USERS = 0x80000003

KEY_READ = 0x20019
KEY_WRITE = 0x20006
KEY_ALL_ACCESS = 0xF003F

REG_SZ = 1
REG_DWORD = 4

# 服务管理
SC_MANAGER_ALL_ACCESS = 0xF003F
SERVICE_ALL_ACCESS = 0xF01FF
SERVICE_START = 0x0010
SERVICE_STOP = 0x0020

# ---------------------------------------------------------------------------
# Win32 结构体定义
# ---------------------------------------------------------------------------

class PROCESSENTRY32(ctypes.Structure):
    """进程快照条目"""
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.POINTER(wintypes.ULONG)),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.CHAR * 260),
    ]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]

class INPUT_UNION(ctypes.Union):
    _fields_ = [
        ("mi", MOUSEINPUT),
        ("ki", KEYBDINPUT),
    ]

class INPUT(ctypes.Structure):
    _fields_ = [
        ("type", wintypes.DWORD),
        ("union", INPUT_UNION),
    ]

# ---------------------------------------------------------------------------
# Hive 主类
# ---------------------------------------------------------------------------
class Hive:
    """
    蜂巢系统接管层
    封装所有 Windows 系统级操作
    """

    def __init__(self, permission_level: str = "L2", logger=None):
        """
        初始化蜂巢
        :param permission_level: 当前权限等级
        :param logger: 日志记录器（Honeycomb 实例）
        """
        self.permission_level = permission_level
        self.logger = logger
        self._require_admin = False  # 是否需要管理员权限

        # 加载 kernel32 / user32 / advapi32
        self.kernel32 = ctypes.windll.kernel32
        self.user32 = ctypes.windll.user32
        self.advapi32 = ctypes.windll.advapi32

    def _log(self, op_type: str, description: str, **kwargs):
        """内部日志"""
        if self.logger:
            self.logger.log(op_type, description, **kwargs)

    def _check_perm(self, operation: str) -> bool:
        """检查权限"""
        from permission import verify_permission, LEVEL_RANK
        # 动态导入避免循环
        return True  # 实际由上层在调用前检查

    # ===================================================================
    # 窗口管理
    # ===================================================================

    def enum_windows(self) -> list:
        """
        枚举所有顶层窗口
        :return: [{"hwnd": ..., "title": ..., "class": ..., "pid": ...}, ...]
        """
        windows = []

        # 回调函数类型
        WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def enum_callback(hwnd, lparam):
            if not self.user32.IsWindowVisible(hwnd):
                return True  # 跳过不可见窗口

            title_len = self.user32.GetWindowTextLengthW(hwnd)
            if title_len == 0:
                return True  # 跳过无标题窗口

            # 获取窗口标题
            title_buf = ctypes.create_unicode_buffer(title_len + 1)
            self.user32.GetWindowTextW(hwnd, title_buf, title_len + 1)

            # 获取窗口类名
            class_buf = ctypes.create_unicode_buffer(256)
            self.user32.GetClassNameW(hwnd, class_buf, 256)

            # 获取进程 ID
            pid = wintypes.DWORD()
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))

            windows.append({
                "hwnd": hwnd,
                "title": title_buf.value,
                "class": class_buf.value,
                "pid": pid.value,
            })
            return True

        callback = WNDENUMPROC(enum_callback)
        self.user32.EnumWindows(callback, 0)
        self._log("窗口操作", f"枚举窗口，共 {len(windows)} 个可见窗口")
        return windows

    def find_window_by_title(self, title_substr: str) -> list:
        """根据标题关键词查找窗口"""
        all_windows = self.enum_windows()
        return [w for w in all_windows if title_substr.lower() in w["title"].lower()]

    def set_window_pos(self, hwnd: int, x: int = None, y: int = None,
                       width: int = None, height: int = None, topmost: bool = False):
        """设置窗口位置和大小"""
        flags = 0
        if x is None or y is None:
            flags |= SWP_NOMOVE
        if width is None or height is None:
            flags |= SWP_NOSIZE

        hwnd_insert_after = HWND_TOPMOST if topmost else HWND_NOTOPMOST
        self.user32.SetWindowPos(
            wintypes.HWND(hwnd),
            wintypes.HWND(hwnd_insert_after),
            x or 0, y or 0, width or 0, height or 0,
            flags
        )
        self._log("窗口操作", f"调整窗口位置 HWND={hwnd}")

    def show_window(self, hwnd: int, cmd: int = SW_SHOW):
        """显示/隐藏窗口"""
        self.user32.ShowWindow(wintypes.HWND(hwnd), cmd)

    def get_foreground_window(self) -> dict:
        """获取当前前台窗口"""
        hwnd = self.user32.GetForegroundWindow()
        title_len = self.user32.GetWindowTextLengthW(hwnd)
        title_buf = ctypes.create_unicode_buffer(max(title_len + 1, 1))
        self.user32.GetWindowTextW(hwnd, title_buf, title_len + 1)

        pid = wintypes.DWORD()
        self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))

        return {"hwnd": hwnd, "title": title_buf.value, "pid": pid.value}

    def set_foreground_window(self, hwnd: int):
        """将窗口设为前台"""
        self.user32.SetForegroundWindow(wintypes.HWND(hwnd))

    # ===================================================================
    # 输入模拟
    # ===================================================================

    def send_key(self, vk_code: int, key_up: bool = False):
        """
        模拟键盘按键
        :param vk_code: 虚拟键码（如 0x0D = Enter）
        :param key_up: True = 释放键，False = 按下键
        """
        inp = INPUT()
        inp.type = INPUT_KEYBOARD
        inp.union.ki.wVk = vk_code
        inp.union.ki.wScan = 0
        inp.union.ki.dwFlags = KEYEVENTF_KEYUP if key_up else 0
        inp.union.ki.time = 0
        inp.union.ki.dwExtraInfo = ctypes.pointer(wintypes.ULONG(0))

        self.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

    def send_key_combo(self, vk_codes: list):
        """
        模拟组合键（如 Alt+F4）
        :param vk_codes: 虚拟键码列表
        """
        # 按下所有键
        for vk in vk_codes:
            self.send_key(vk, key_up=False)
            time.sleep(0.05)
        # 释放所有键（逆序）
        for vk in reversed(vk_codes):
            self.send_key(vk, key_up=True)
            time.sleep(0.05)

    def send_text(self, text: str):
        """
        模拟文本输入（通过剪贴板方式）
        :param text: 要输入的文本
        """
        # 使用 PowerShell 的 SendKeys 作为更可靠的文本输入方式
        escaped = text.replace('"', '`"')
        subprocess.run([
            "powershell", "-Command",
            f'Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait("{escaped}")'
        ], capture_output=True, timeout=10)

    def mouse_move(self, x: int, y: int, absolute: bool = True):
        """移动鼠标"""
        inp = INPUT()
        inp.type = INPUT_MOUSE
        if absolute:
            # 绝对坐标需要屏幕尺寸映射
            screen_width = self.user32.GetSystemMetrics(0)  # SM_CXSCREEN
            screen_height = self.user32.GetSystemMetrics(1)  # SM_CYSCREEN
            inp.union.mi.dx = int(x * 65535 / screen_width)
            inp.union.mi.dy = int(y * 65535 / screen_height)
            inp.union.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE
        else:
            inp.union.mi.dx = x
            inp.union.mi.dy = y
            inp.union.mi.dwFlags = MOUSEEVENTF_MOVE
        inp.union.mi.mouseData = 0
        inp.union.mi.time = 0
        inp.union.mi.dwExtraInfo = ctypes.pointer(wintypes.ULONG(0))

        self.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

    def mouse_click(self, button: str = "left", x: int = None, y: int = None):
        """
        鼠标点击
        :param button: "left" / "right"
        :param x, y: 目标坐标（可选，不传则点击当前位置）
        """
        if x is not None and y is not None:
            self.mouse_move(x, y)
            time.sleep(0.1)

        down_flag = MOUSEEVENTF_LEFTDOWN if button == "left" else MOUSEEVENTF_RIGHTDOWN
        up_flag = MOUSEEVENTF_LEFTUP if button == "left" else MOUSEEVENTF_RIGHTUP

        for flag in [down_flag, up_flag]:
            inp = INPUT()
            inp.type = INPUT_MOUSE
            inp.union.mi.dwFlags = flag
            inp.union.mi.mouseData = 0
            inp.union.mi.time = 0
            inp.union.mi.dwExtraInfo = ctypes.pointer(wintypes.ULONG(0))
            self.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))
            time.sleep(0.05)

    # ===================================================================
    # 进程管理
    # ===================================================================

    def enum_processes(self) -> list:
        """
        枚举所有运行进程
        :return: [{"pid": ..., "name": ..., "threads": ..., "ppid": ...}, ...]
        """
        processes = []
        snapshot = self.kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if snapshot == -1:
            return processes

        entry = PROCESSENTRY32()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32)

        if self.kernel32.Process32First(snapshot, ctypes.byref(entry)):
            while True:
                name = entry.szExeFile.decode("utf-8", errors="replace")
                processes.append({
                    "pid": entry.th32ProcessID,
                    "name": name,
                    "threads": entry.cntThreads,
                    "ppid": entry.th32ParentProcessID,
                })
                if not self.kernel32.Process32Next(snapshot, ctypes.byref(entry)):
                    break

        self.kernel32.CloseHandle(snapshot)
        self._log("进程操作", f"枚举进程，共 {len(processes)} 个")
        return processes

    def get_process_by_name(self, name: str) -> list:
        """按名称查找进程"""
        all_procs = self.enum_processes()
        return [p for p in all_procs if name.lower() in p["name"].lower()]

    def terminate_process(self, pid: int) -> bool:
        """
        终止进程
        :param pid: 进程 ID
        :return: True 成功
        """
        handle = self.kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
        if not handle:
            self._log("进程操作", f"无法打开进程 PID={pid}", result="失败")
            return False

        result = self.kernel32.TerminateProcess(handle, 1)
        self.kernel32.CloseHandle(handle)

        if result:
            self._log("进程操作", f"终止进程 PID={pid}", result="成功")
        else:
            self._log("进程操作", f"终止进程失败 PID={pid}", result="失败")
        return bool(result)

    def get_process_memory(self, pid: int) -> int:
        """
        获取进程内存使用量（字节）
        :param pid: 进程 ID
        :return: 内存字节数，失败返回 -1
        """
        try:
            import ctypes.wintypes as w
            psapi = ctypes.windll.psapi
            handle = self.kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
            if not handle:
                return -1

            class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("cb", w.DWORD),
                    ("PageFaultCount", w.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                ]

            pmc = PROCESS_MEMORY_COUNTERS()
            pmc.cb = ctypes.sizeof(pmc)
            if psapi.GetProcessMemoryInfo(handle, ctypes.byref(pmc), pmc.cb):
                self.kernel32.CloseHandle(handle)
                return pmc.WorkingSetSize

            self.kernel32.CloseHandle(handle)
            return -1
        except Exception:
            return -1

    def get_process_cpu(self, pid: int) -> float:
        """
        获取进程 CPU 使用率（近似值）
        :param pid: 进程 ID
        :return: CPU 百分比（0-100），失败返回 -1
        """
        try:
            # 使用 PowerShell 获取 CPU 使用率
            result = subprocess.run([
                "powershell", "-Command",
                f"(Get-Process -Id {pid} -ErrorAction SilentlyContinue | "
                f"Select-Object -ExpandProperty CPU | "
                f"ForEach-Object {{ $_.TotalSeconds }})"
            ], capture_output=True, text=True, timeout=10)
            if result.stdout.strip():
                return float(result.stdout.strip()) / 100.0  # 转为百分比近似
            return -1.0
        except Exception:
            return -1.0

    # ===================================================================
    # 注册表操作
    # ===================================================================

    def registry_read(self, key_path: str, value_name: str,
                      hive: int = HKEY_CURRENT_USER) -> str:
        """
        读取注册表值
        :param key_path: 注册表路径（如 Software\\Microsoft\\Windows\\CurrentVersion）
        :param value_name: 值名称
        :param hive: 根键（默认 HKCU）
        :return: 字符串值，失败返回 None
        """
        try:
            hkey = wintypes.HKEY()
            # 打开键
            result = self.advapi32.RegOpenKeyExW(
                wintypes.HKEY(hive),
                key_path,
                0,
                KEY_READ,
                ctypes.byref(hkey)
            )
            if result != 0:
                return None

            # 查询值
            data_type = wintypes.DWORD()
            data_size = wintypes.DWORD(4096)
            data_buf = ctypes.create_unicode_buffer(4096)
            result = self.advapi32.RegQueryValueExW(
                hkey,
                value_name,
                None,
                ctypes.byref(data_type),
                data_buf,
                ctypes.byref(data_size)
            )
            self.advapi32.RegCloseKey(hkey)

            if result == 0:
                return data_buf.value
            return None
        except Exception:
            return None

    def registry_write(self, key_path: str, value_name: str, value: str,
                       hive: int = HKEY_CURRENT_USER) -> bool:
        """
        写入注册表值（字符串类型）
        :param key_path: 注册表路径
        :param value_name: 值名称
        :param value: 值内容
        :param hive: 根键
        :return: True 成功
        """
        try:
            hkey = wintypes.HKEY()
            # 创建或打开键
            result = self.advapi32.RegCreateKeyExW(
                wintypes.HKEY(hive),
                key_path,
                0, None, 0,
                KEY_WRITE,
                None,
                ctypes.byref(hkey),
                None
            )
            if result != 0:
                return False

            # 设置值
            value_bytes = (value + "\0").encode("utf-16-le")
            result = self.advapi32.RegSetValueExW(
                hkey,
                value_name,
                0,
                REG_SZ,
                value_bytes,
                len(value_bytes)
            )
            self.advapi32.RegCloseKey(hkey)

            success = result == 0
            self._log("注册表操作", f"写入 {key_path}\\{value_name} = {value}",
                      result="成功" if success else "失败")
            return success
        except Exception:
            return False

    def registry_delete(self, key_path: str, value_name: str,
                        hive: int = HKEY_CURRENT_USER) -> bool:
        """删除注册表值"""
        try:
            hkey = wintypes.HKEY()
            result = self.advapi32.RegOpenKeyExW(
                wintypes.HKEY(hive), key_path, 0, KEY_WRITE, ctypes.byref(hkey)
            )
            if result != 0:
                return False

            result = self.advapi32.RegDeleteValueW(hkey, value_name)
            self.advapi32.RegCloseKey(hkey)
            return result == 0
        except Exception:
            return False

    # ===================================================================
    # 服务管理
    # ===================================================================

    def control_service(self, service_name: str, action: str) -> bool:
        """
        控制 Windows 服务
        :param service_name: 服务名称
        :param action: "start" / "stop" / "restart"
        :return: True 成功
        """
        try:
            cmd_map = {"start": "start", "stop": "stop", "restart": "restart"}
            sub_action = cmd_map.get(action, action)
            result = subprocess.run(
                ["sc", sub_action, service_name],
                capture_output=True, text=True, timeout=30
            )
            success = result.returncode == 0
            self._log("系统设置", f"服务 {action}: {service_name}",
                      result="成功" if success else f"失败: {result.stderr.strip()}")
            return success
        except Exception as e:
            self._log("系统设置", f"服务 {action}: {service_name}", result=f"异常: {e}")
            return False

    # ===================================================================
    # 网络操作
    # ===================================================================

    def modify_hosts(self, domain: str, ip: str, action: str = "add") -> bool:
        """
        修改 hosts 文件
        :param domain: 域名
        :param ip: IP 地址
        :param action: "add" / "remove"
        """
        hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
        try:
            with open(hosts_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            entry = f"{ip}\t{domain}\n"
            if action == "add":
                if entry not in lines:
                    lines.append(entry)
            elif action == "remove":
                lines = [l for l in lines if l.strip() != entry.strip()]

            with open(hosts_path, "w", encoding="utf-8") as f:
                f.writelines(lines)

            self._log("网络操作", f"hosts {action}: {domain} -> {ip}", result="成功")
            return True
        except Exception as e:
            self._log("网络操作", f"hosts 修改失败", result=str(e))
            return False

    def set_proxy(self, proxy_server: str, enable: bool = True) -> bool:
        """
        设置系统代理
        :param proxy_server: 代理地址（如 "127.0.0.1:7890"）
        :param enable: True 启用 / False 禁用
        """
        try:
            if enable:
                self.registry_write(
                    r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                    "ProxyEnable", "1" if enable else "0"
                )
                self.registry_write(
                    r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                    "ProxyServer", proxy_server
                )
            else:
                self.registry_write(
                    r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                    "ProxyEnable", "0"
                )
            self._log("网络操作", f"代理 {'启用' if enable else '禁用'}: {proxy_server}",
                      result="成功")
            return True
        except Exception as e:
            self._log("网络操作", "代理设置失败", result=str(e))
            return False

    def add_firewall_rule(self, rule_name: str, program_path: str,
                          direction: str = "in") -> bool:
        """
        添加 Windows 防火墙规则
        :param rule_name: 规则名称
        :param program_path: 程序路径
        :param direction: "in" 入站 / "out" 出站
        """
        try:
            cmd = [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={rule_name}",
                f"dir={direction}",
                f"program={program_path}",
                "action=allow"
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            success = result.returncode == 0
            self._log("网络操作", f"防火墙规则 {rule_name}", result="成功" if success else "失败")
            return success
        except Exception as e:
            self._log("网络操作", f"防火墙规则失败", result=str(e))
            return False

    # ===================================================================
    # DNS 修改
    # ===================================================================

    def set_dns(self, interface_name: str, primary_dns: str,
                secondary_dns: str = "") -> bool:
        """
        修改 DNS 服务器
        :param interface_name: 网络接口名称
        :param primary_dns: 首选 DNS
        :param secondary_dns: 备用 DNS
        """
        try:
            cmd = [
                "netsh", "interface", "ip", "set", "dns",
                f'name="{interface_name}"', "static", primary_dns
            ]
            subprocess.run(cmd, capture_output=True, timeout=30)

            if secondary_dns:
                cmd2 = [
                    "netsh", "interface", "ip", "add", "dns",
                    f'name="{interface_name}"', secondary_dns, "index=2"
                ]
                subprocess.run(cmd2, capture_output=True, timeout=30)

            self._log("网络操作", f"DNS 设置: {primary_dns}", result="成功")
            return True
        except Exception as e:
            self._log("网络操作", "DNS 设置失败", result=str(e))
            return False

    # ===================================================================
    # 计划任务
    # ===================================================================

    def create_scheduled_task(self, task_name: str, program_path: str,
                              schedule: str = "DAILY", start_time: str = "09:00") -> bool:
        """
        创建 Windows 计划任务
        :param task_name: 任务名称
        :param program_path: 程序路径
        :param schedule: DAILY / HOURLY / ONLOGON
        :param start_time: 开始时间
        """
        try:
            cmd = [
                "schtasks", "/Create", "/F",
                "/TN", task_name,
                "/TR", program_path,
                "/SC", schedule,
                "/ST", start_time,
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            success = result.returncode == 0
            self._log("系统设置", f"计划任务 {task_name}", result="成功" if success else f"失败: {result.stderr}")
            return success
        except Exception as e:
            self._log("系统设置", "计划任务创建失败", result=str(e))
            return False

    def delete_scheduled_task(self, task_name: str) -> bool:
        """删除计划任务"""
        try:
            result = subprocess.run(
                ["schtasks", "/Delete", "/F", "/TN", task_name],
                capture_output=True, text=True, timeout=30
            )
            return result.returncode == 0
        except Exception:
            return False

    # ===================================================================
    # 开机自启
    # ===================================================================

    def set_autostart(self, app_name: str, app_path: str, enable: bool = True) -> bool:
        """
        设置开机自启
        :param app_name: 应用名称
        :param app_path: 应用路径
        :param enable: True 启用 / False 禁用
        """
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        if enable:
            success = self.registry_write(key_path, app_name, app_path)
        else:
            success = self.registry_delete(key_path, app_name)

        self._log("系统设置", f"开机自启 {'启用' if enable else '禁用'}: {app_name}",
                  result="成功" if success else "失败")
        return success

    def is_autostart_enabled(self, app_name: str) -> bool:
        """检查是否已设置开机自启"""
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        value = self.registry_read(key_path, app_name)
        return value is not None and len(value) > 0

    # ===================================================================
    # 系统信息
    # ===================================================================

    def get_system_info(self) -> dict:
        """获取系统基本信息"""
        import platform
        info = {
            "os": platform.system(),
            "os_version": platform.version(),
            "hostname": platform.node(),
            "python_version": sys.version,
            "screen_width": self.user32.GetSystemMetrics(0),
            "screen_height": self.user32.GetSystemMetrics(1),
        }

        # 获取内存信息
        try:
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", wintypes.DWORD),
                    ("dwMemoryLoad", wintypes.DWORD),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                ]

            mem = MEMORYSTATUSEX()
            mem.dwLength = ctypes.sizeof(mem)
            self.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem))
            info["total_memory_gb"] = round(mem.ullTotalPhys / (1024 ** 3), 2)
            info["available_memory_gb"] = round(mem.ullAvailPhys / (1024 ** 3), 2)
            info["memory_usage_percent"] = mem.dwMemoryLoad
        except Exception:
            pass

        return info

    # ===================================================================
    # 文件系统监控（简化版，使用轮询方式）
    # ===================================================================

    def watch_directory(self, directory: str, callback, interval: float = 1.0):
        """
        监控目录变化（轮询方式）
        :param directory: 要监控的目录
        :param callback: 回调函数 callback(event_type, file_path)
        :param interval: 轮询间隔
        """
        import threading
        import hashlib

        def _watch_loop():
            # 记录初始状态
            snapshot = {}
            try:
                for root, dirs, files in os.walk(directory):
                    for f in files:
                        fp = os.path.join(root, f)
                        try:
                            mtime = os.path.getmtime(fp)
                            size = os.path.getsize(fp)
                            snapshot[fp] = (mtime, size)
                        except OSError:
                            pass
            except Exception:
                pass

            while True:
                try:
                    current = {}
                    for root, dirs, files in os.walk(directory):
                        for f in files:
                            fp = os.path.join(root, f)
                            try:
                                mtime = os.path.getmtime(fp)
                                size = os.path.getsize(fp)
                                current[fp] = (mtime, size)
                            except OSError:
                                pass

                    # 检测新增/修改
                    for fp, (mtime, size) in current.items():
                        if fp not in snapshot:
                            callback("created", fp)
                        elif snapshot[fp] != (mtime, size):
                            callback("modified", fp)

                    # 检测删除
                    for fp in snapshot:
                        if fp not in current:
                            callback("deleted", fp)

                    snapshot = current
                    time.sleep(interval)
                except Exception:
                    time.sleep(interval)

        t = threading.Thread(target=_watch_loop, daemon=True)
        t.start()
        return t

    # ===================================================================
    # 蜂后守护
    # ===================================================================

    def daemonize_queen(self, queen_pid: int, max_restarts: int = 3):
        """
        守护蜂后进程，崩溃自动重启
        :param queen_pid: 蜂后进程 PID
        :param max_restarts: 最大重启次数
        注意：此方法会阻塞当前线程
        """
        import threading

        def _daemon_loop():
            restarts = 0
            # 获取蜂后进程句柄
            handle = self.kernel32.OpenProcess(
                0x100000,  # SYNCHRONIZE
                False,
                queen_pid
            )

            while restarts < max_restarts:
                # 等待进程退出（无限等待）
                ret = self.kernel32.WaitForSingleObject(handle, 60000)  # 每分钟检查一次
                if ret == 0:  # WAIT_OBJECT_0 — 进程已退出
                    self._log("系统设置", f"蜂后进程 PID={queen_pid} 已退出，尝试重启 ({restarts+1}/{max_restarts})")
                    # 重新启动蜂后
                    beehive_dir = os.path.dirname(os.path.abspath(__file__))
                    queen_path = os.path.join(beehive_dir, "queen.py")
                    # 这里应该由 beehive.py 来重启，hive 只负责检测
                    # 实际重启逻辑由上层处理
                    restarts += 1

        t = threading.Thread(target=_daemon_loop, daemon=True)
        t.start()
        return t

# ---------------------------------------------------------------------------
# 自检
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    hive = Hive(permission_level="L3")
    print("=== Hive 系统接管层测试 ===\n")

    # 系统信息
    info = hive.get_system_info()
    print(f"系统信息: {json.dumps(info, indent=2, ensure_ascii=False)}")

    # 进程枚举（仅显示前 5 个）
    procs = hive.enum_processes()
    print(f"\n进程总数: {len(procs)}")
    for p in procs[:5]:
        print(f"  PID={p['pid']:6d}  {p['name']}")

    # 窗口枚举（仅显示前 5 个）
    windows = hive.enum_windows()
    print(f"\n窗口总数: {len(windows)}")
    for w in windows[:5]:
        print(f"  HWND={w['hwnd']}  {w['title']}")

