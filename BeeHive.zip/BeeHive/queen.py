#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
蜂后 (Queen) — LLM 推理 + 工蜂调度 + 守卫蜂 + 日志

LLM 推理部分完全照搬 AntNest 的成熟实现（SSE 流式解析、Think 重复检测、
完整的请求参数构建），在此基础上附加 BeeHive 的守卫蜂、权限、日志系统。

运行方式：
    python queen.py              # 交互模式
    python queen.py "任务描述"    # 单任务模式
"""

import os
import sys
import re
import json
import time
import uuid
import socket
import shutil
import subprocess
import threading
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# 项目根目录
# ---------------------------------------------------------------------------
BEEHIVE_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BEEHIVE_ROOT)

import honeycomb as honeycomb_mod
import permission as perm_mod

# ---------------------------------------------------------------------------
# 配置加载（三级优先级：环境变量 > local_config.json > 默认值）
# 同时兼容 AntNest 的 ANT_ 前缀和 BeeHive 的 BEEHIVE_ 前缀
# ---------------------------------------------------------------------------
LOCAL_CONFIG = os.path.join(BEEHIVE_ROOT, "local_config.json")
CONFIG_TEMPLATE = os.path.join(BEEHIVE_ROOT, "config.json")

_config = {}
for _p in [CONFIG_TEMPLATE, LOCAL_CONFIG]:
    if os.path.exists(_p):
        try:
            with open(_p, "r", encoding="utf-8") as _f:
                _cfg = json.loads(_f.read())
            for _k in ("api", "agent", "security", "hive"):
                if _k in _cfg and _k not in _config:
                    _config[_k] = _cfg[_k]
                elif _k in _cfg:
                    _config[_k].update(_cfg[_k])
        except Exception:
            pass

_cfg_api = _config.get("api", {})
ANT_BASE_URL = (os.environ.get("ANT_BASE_URL")
                or os.environ.get("BEEHIVE_BASE_URL")
                or _cfg_api.get("base_url", "https://api.deepseek.com/v1"))
ANT_MODEL_NAME = (os.environ.get("ANT_MODEL_NAME")
                  or os.environ.get("BEEHIVE_MODEL_NAME")
                  or _cfg_api.get("model_name", "deepseek-chat"))
ANT_API_KEY = (os.environ.get("ANT_API_KEY")
               or os.environ.get("BEEHIVE_API_KEY")
               or _cfg_api.get("api_key", ""))

if not ANT_API_KEY:
    print("错误：未配置 API Key。请在 local_config.json 中设置 api.api_key，")
    print("或设置环境变量 ANT_API_KEY / BEEHIVE_API_KEY")
    print(f"配置文件位置：{LOCAL_CONFIG}")
    sys.exit(1)

COMMON_HEADER = {"User-Agent": "BeeHive", "Authorization": f"Bearer {ANT_API_KEY}"}

# ---------------------------------------------------------------------------
# Agent 配置
# ---------------------------------------------------------------------------
_cfg_agent = _config.get("agent", {})
_cfg_security = _config.get("security", {})
_cfg_hive = _config.get("hive", {})

TOKEN_CAP = int(os.environ.get("BEEHIVE_TOKEN_CAP") or _cfg_agent.get("token_cap", 100000))
COMPACT_THRESH = float(os.environ.get("ANT_COMPACT_THRESH")
                       or os.environ.get("BEEHIVE_COMPACT_THRESH")
                       or _cfg_agent.get("compact_threshold", 0.85))
TOOL_RESULT_LEN = int(os.environ.get("ANT_TOOL_RESULT_LEN")
                      or os.environ.get("BEEHIVE_TOOL_RESULT_LEN")
                      or _cfg_agent.get("tool_result_max_len", min(8000, int(TOKEN_CAP / 20))))
MAX_DEPTH = int(os.environ.get("AN_MAX_DEPTH")
                or os.environ.get("BEEHIVE_MAX_DEPTH")
                or _cfg_agent.get("max_depth", 3))
MAX_WORKERS = int(os.environ.get("BEEHIVE_MAX_WORKERS") or _cfg_agent.get("max_workers", 8))
WORKER_TIMEOUT = int(os.environ.get("BEEHIVE_WORKER_TIMEOUT") or _cfg_agent.get("worker_timeout", 300))

PERMISSION_LEVEL = (os.environ.get("BEEHIVE_PERMISSION_LEVEL")
                    or _cfg_security.get("permission_level", "L2"))

COMPACT_PANIC = False
LAST_USAGE = None

# ---------------------------------------------------------------------------
# 目录常量
# ---------------------------------------------------------------------------
CLONE_POOL_DIR = os.path.join(BEEHIVE_ROOT, "clone_pool")
SESSIONS_DIR = os.path.join(BEEHIVE_ROOT, "sessions")
MEMORY_DIR = os.path.join(BEEHIVE_ROOT, "memory")
LOGS_DIR = os.path.join(BEEHIVE_ROOT, "logs")
HIVE_KNOWLEDGE = os.path.join(MEMORY_DIR, "hive_knowledge.md")
HINTS_FILE = os.path.join(MEMORY_DIR, "hints.md")

# ---------------------------------------------------------------------------
# 跨平台
# ---------------------------------------------------------------------------
IS_WINDOWS = os.name == "nt"
SHELL = "powershell" if IS_WINDOWS else "bash"
SHELL_FLAG = "-Command" if IS_WINDOWS else "-c"

# ---------------------------------------------------------------------------
# 颜色
# ---------------------------------------------------------------------------
class Colors:
    RESET = "\033[0m"
    QUEEN = "\033[1;35m"
    THINK = "\033[2m"
    WARN = "\033[1;33m"
    ERROR = "\033[1;31m"
    SUCCESS = "\033[1;32m"

# ---------------------------------------------------------------------------
# 日志初始化
# ---------------------------------------------------------------------------
queen_logger = honeycomb_mod.create_logger("queen")

def log(msg: str, op_type: str = "蜂后操作", duration: float = 0.0, result: str = ""):
    """蜂后日志（写入文件 + 控制台）"""
    if op_type == "系统设置":
        print(f"[蜂后] {msg}")
    queen_logger.log(op_type, msg, duration, result)

def log_color(msg: str, color: str = None):
    print(f"{color or Colors.QUEEN}[蜂后] {msg}{Colors.RESET}")

# ====================== 环境探针 ======================
def collect_env_info():
    """启动时收集系统信息注入 system prompt（照搬 AntNest）"""
    import platform

    cmds = {
        "Windows": [
            "[System.Environment]::OSVersion.VersionString",
            "foreach ($t in @('python','node','git','docker')) { $cmd = Get-Command $t -ErrorAction SilentlyContinue; if ($cmd) { $v = & $t --version 2>&1 | Select-Object -First 1; Write-Output \"$t`: $v\" } else { Write-Output \"$t`: 未安装\" } }",
            "Get-ChildItem -Force | Where-Object { $_.Name -ne '.' -and $_.Name -ne '..' } | ForEach-Object { if ($_.PSIsContainer) { Write-Output \"[目录] $($_.Name)\" } else { Write-Output \"[文件] $($_.Name)\" } }",
        ],
    }
    labels = ["=== 系统 ===", "=== 已安装工具 ===", f"=== 当前目录 {BEEHIVE_ROOT} ==="]
    results = []

    for label, cmd in zip(labels, cmds["Windows"]):
        try:
            r = subprocess.run([SHELL, SHELL_FLAG, cmd], capture_output=True,
                               text=True, errors="replace", timeout=5,
                               creationflags=subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0)
            output = r.stdout.strip()
            if not output:
                continue
            # 第3个命令（文件列表）需要截断
            if "当前目录" in label:
                lines = output.splitlines()
                total = len(lines)
                kept, chars = [], 0
                for line in lines:
                    if len(kept) >= 100 or chars + len(line) + 1 > 2000:
                        break
                    kept.append(line)
                    chars += len(line) + 1
                output = "\n".join(kept)
                hidden = total - len(kept)
                if hidden > 0:
                    output += f"\n...还有 {hidden} 个文件未显示"
            results.append(f"{label}\n{output}")
        except Exception:
            pass

    today = datetime.now().strftime("%Y-%m-%d")
    return f"=== 今天日期 ===\n{today}\n\n" + ("\n\n".join(results) if results else "环境信息获取失败")

ENV_INFO = collect_env_info()

# ---------------------------------------------------------------------------
# System Prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = f"""# 你是谁
你是 BeeHive 蜂后，一个采用蜂后/工蜂/守卫蜂架构的桌面自动化 AI Agent。

# 架构说明
你当前运行在 **蜂后模式（depth=0）**。你从不亲自执行命令——
- 你需要执行操作时，使用 spawn_worker 生成 **工蜂** 去隔离目录执行
- 工蜂执行完毕后将结果写入文件，退出后被销毁
- 守卫蜂在后台监控所有工蜂，异常时直接 kill 并通知你

# 工具使用规则（极其重要）
- 蜂后（depth=0）只能 spawn_worker，禁止其他方式执行命令
- 工蜂（depth=1）可以 spawn_worker 拆分子任务
- 子工蜂（depth=2）禁止继续 spawn，降级为直接执行
- depth>={MAX_DEPTH} 时硬拦截 spawn
- 无依赖的并行任务应一次性 spawn 多只工蜂加速

# 你在哪
- 操作系统：Windows
- 工作目录：{BEEHIVE_ROOT}
- 最大工蜂数：{MAX_WORKERS}
- 当前权限等级：{PERMISSION_LEVEL}
- 工蜂超时：{WORKER_TIMEOUT}s

# 当前环境
{{env_info}}

# 你要做什么
1. 帮助人类完成任务，结果要可验证、可靠
2. 复杂任务拆分为多个子任务并行执行
3. 任务完成后主动验证结果

# 固化的知识及规则（hive_knowledge.md）
<knowledge_and_rules>
{{knowledge}}
</knowledge_and_rules>

# 记忆线索（hints.md）
<memory_hints>
{{hints}}
</memory_hints>
"""

COMPACT_PROMPT = """《紧急》记忆即将达到上限。请整理关键信息写入记忆文件，并调用 leave_memory_hints 留下线索。"""

# ====================== 工具定义 ======================
spawn_worker_schema = {
    "type": "function",
    "function": {
        "name": "spawn_worker",
        "description": (
            "生成一只工蜂去执行命令。工蜂在隔离的临时目录中运行，"
            "执行完毕后将结果写回，然后被销毁。"
            "当前为蜂后模式（depth=0），所有执行必须通过此工具。"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "工蜂要执行的完整命令",
                },
                "timeout": {
                    "type": "integer",
                    "default": WORKER_TIMEOUT,
                    "description": "超时时间（秒）",
                },
                "label": {
                    "type": "string",
                    "description": "工蜂标签，如 '下载文件'、'数据分析'",
                },
            },
            "required": ["command"],
        },
    },
}

memory_hints_schema = {
    "type": "function",
    "function": {
        "name": "leave_memory_hints",
        "description": "压缩对话历史并保存记忆线索到 hints.md。",
        "parameters": {
            "type": "object",
            "properties": {
                "hints": {"type": "string", "description": "记忆线索文本"},
            },
            "required": ["hints"],
        },
    },
}

# ====================== 工蜂管理（照搬 AntNest spawn_clone） ======================
def spawn_worker(command: str, timeout: int = WORKER_TIMEOUT, label: str = "") -> str:
    """
    生成工蜂执行命令。
    1. 深度硬拦截
    2. 在 clone_pool 下创建隔离目录
    3. 命令通过文件传递（超长命令防截断）
    4. 复制 worker.py 到隔离目录
    5. 以 clone 模式启动工蜂
    6. 等待执行完毕，读取 result.json
    7. finally 中 rmtree 销毁目录
    """
    current_depth = int(os.environ.get("BEEHIVE_DEPTH", "0"))
    if current_depth >= MAX_DEPTH:
        return json.dumps({
            "status": "blocked",
            "error": f"深度限制：当前 depth={current_depth} >= MAX_DEPTH={MAX_DEPTH}，spawn_worker 已硬拦截",
        }, ensure_ascii=False)

    clone_id = uuid.uuid4().hex[:8]
    worker_id = f"worker_{clone_id}"
    clone_dir = os.path.join(CLONE_POOL_DIR, f"clone_{clone_id}")
    os.makedirs(clone_dir, exist_ok=True)

    # 复制 worker.py 到隔离目录
    worker_src = os.path.join(BEEHIVE_ROOT, "worker.py")
    worker_dst = os.path.join(clone_dir, "worker.py")
    shutil.copy2(worker_src, worker_dst)

    result_file = os.path.join(clone_dir, "result.json")

    # 命令传递：超长用文件
    MAX_ENV_LEN = 8000
    if len(command) > MAX_ENV_LEN:
        cmd_file = os.path.join(clone_dir, "command.txt")
        with open(cmd_file, "w", encoding="utf-8") as f:
            f.write(command)
        use_cmd_file = True
    else:
        use_cmd_file = False

    label_str = label or clone_id
    log(f"孵化工蜂 {worker_id}: {command[:100]}{'...' if len(command) > 100 else ''}", "工蜂操作")
    print(f"\n[工蜂] {label_str} → {clone_dir}")

    try:
        env = os.environ.copy()
        env["BEEHIVE_CLONE_MODE"] = "1"
        env["BEEHIVE_WORKER_ID"] = worker_id
        env["BEEHIVE_PERMISSION_LEVEL"] = PERMISSION_LEVEL
        env["BEEHIVE_RESULT_FILE"] = result_file
        env["BEEHIVE_DEPTH"] = str(current_depth + 1)
        env["BEEHIVE_TIMEOUT"] = str(timeout)
        env["AN_CLONE_DIR"] = clone_dir  # 兼容工蜂内部路径引用
        env["BEEHIVE_LABEL"] = label_str

        if use_cmd_file:
            env["BEEHIVE_COMMAND_FILE"] = cmd_file
            env["BEEHIVE_COMMAND"] = ""
        else:
            env["BEEHIVE_COMMAND"] = command

        proc = subprocess.Popen(
            [sys.executable, worker_dst],
            cwd=clone_dir,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0,
        )

        # 注册到守卫蜂
        _register_to_guard(worker_id, proc.pid, clone_dir, PERMISSION_LEVEL, timeout, current_depth)

        try:
            stdout, stderr = proc.communicate(timeout=timeout + 60)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
            log(f"工蜂 {worker_id} 超时，已强制终止", "工蜂操作", result="超时")
            _unregister_from_guard(worker_id)
            return json.dumps({
                "status": "timeout",
                "error": f"工蜂执行超时（{timeout}s）",
            }, ensure_ascii=False)

        # 读取结果
        if os.path.exists(result_file):
            with open(result_file, "r", encoding="utf-8") as f:
                result = f.read()
        else:
            result = json.dumps({
                "status": "error",
                "error": "工蜂未生成结果文件",
                "stdout": stdout[:2000] if stdout else "",
                "stderr": stderr[:2000] if stderr else "",
            }, ensure_ascii=False)

        log(f"工蜂 {worker_id} 完成 exit={proc.returncode}", "工蜂操作",
            duration=timeout, result="ok" if proc.returncode==0 else "error")
        print(f"[工蜂] {label_str} 完成 (exit={proc.returncode})")

        return result

    except Exception as e:
        log(f"工蜂异常: {e}", "工蜂操作", result="异常")
        return json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False)

    finally:
        _unregister_from_guard(worker_id)
        try:
            shutil.rmtree(clone_dir, ignore_errors=True)
        except Exception:
            pass


# 守卫蜂注册（worker_registry.json）
def _write_registry(registry: dict):
    """带文件锁的注册表写入，防止读写竞态"""
    import msvcrt
    lockfile = os.path.join(CLONE_POOL_DIR, "registry.lock")
    with open(lockfile, "w") as lf:
        msvcrt.locking(lf.fileno(), msvcrt.LK_LOCK, 1)
        try:
            tmpfile = os.path.join(CLONE_POOL_DIR, "worker_registry.tmp")
            with open(tmpfile, "w", encoding="utf-8") as f:
                json.dump(registry, f, ensure_ascii=False, indent=2)
            os.replace(tmpfile, os.path.join(CLONE_POOL_DIR, "worker_registry.json"))
        finally:
            msvcrt.locking(lf.fileno(), msvcrt.LK_UNLCK, 1)

def _read_registry() -> dict:
    import msvcrt
    lockfile = os.path.join(CLONE_POOL_DIR, "registry.lock")
    registry_file = os.path.join(CLONE_POOL_DIR, "worker_registry.json")
    with open(lockfile, "w") as lf:
        msvcrt.locking(lf.fileno(), msvcrt.LK_LOCK, 1)
        try:
            if os.path.exists(registry_file):
                with open(registry_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            return {}
        finally:
            msvcrt.locking(lf.fileno(), msvcrt.LK_UNLCK, 1)

def _register_to_guard(worker_id, pid, work_dir, perm_level, timeout, depth):
    try:
        registry = _read_registry()
        registry[worker_id] = {
            "pid": pid, "work_dir": work_dir,
            "permission_level": perm_level,
            "timeout": timeout, "depth": depth,
            "start_time": time.time(),
        }
        _write_registry(registry)
        log(f"工蜂已注册: {worker_id} PID={pid}, 当前活跃={len(registry)}", "工蜂操作")
    except Exception as e:
        log(f"工蜂注册失败: {e}", "工蜂操作", result="异常")

def _unregister_from_guard(worker_id):
    try:
        registry = _read_registry()
        if worker_id in registry:
            del registry[worker_id]
            _write_registry(registry)
            log(f"工蜂已注销: {worker_id}, 剩余活跃={len(registry)}", "工蜂操作")
    except Exception as e:
        log(f"工蜂注销失败: {e}", "工蜂操作", result="异常")


# ====================== 记忆管理 ======================
def _trim_tool_content(msg):
    if msg.get("role") == "tool" and msg.get("content") and len(msg["content"]) > 400:
        c = msg["content"]
        msg = {**msg, "content": c[:200] + "\n…（中间省略）…\n" + c[-200:]}
    return msg

def leave_memory_hints(hints):
    global messages, COMPACT_PANIC

    compact_i = -1
    for i in range(len(messages) - 1, -1, -1):
        if messages[i]["role"] == "user" and messages[i]["content"] == COMPACT_PROMPT:
            compact_i = i
            break

    last_user_i = compact_i - 1
    for i in range(last_user_i, -1, -1):
        if messages[i]["role"] == "user":
            last_user_i = i
            break

    kept = []
    for m in messages[last_user_i:compact_i]:
        kept.append(_trim_tool_content(m))

    knowledge = _read_knowledge()
    hints_content = hints or ""

    messages.clear()
    messages.append({
        "role": "system",
        "content": SYSTEM_PROMPT.format(
            knowledge=knowledge or "无",
            hints=hints_content,
            env_info=ENV_INFO,
        ),
    })
    messages.append({
        "role": "user",
        "content": "《系统提示》记忆已压缩。你之前调用 leave_memory_hints 留下了关键线索，请确认任务状态并继续。",
    })
    messages.extend(kept)

    COMPACT_PANIC = False

    os.makedirs(MEMORY_DIR, exist_ok=True)
    with open(HINTS_FILE, "w", encoding="utf-8") as f:
        f.write(hints_content)

    log("记忆压缩完成", "蜂后操作")
    return "已留下记忆线索，对话已压缩。"

def _read_knowledge():
    try:
        with open(HIVE_KNOWLEDGE, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""

def _read_hints():
    try:
        with open(HINTS_FILE, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""


# ====================== LLM 调用（完整照搬 AntNest） ======================
def clean_input(text):
    if not isinstance(text, str):
        return str(text)
    text = re.sub(r"[\ud800-\udfff\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)
    return text

def _is_thinking_model():
    """判断当前模型是否支持 thinking 参数（deepseek-v4 / deepseek-reasoner 系列）"""
    name = ANT_MODEL_NAME.lower()
    return any(x in name for x in ("v4", "reasoner", "r1", "o1", "o3"))

def _build_request_data(messages, tools=None, temperature=0.6, thinking=True, stream=False):
    """构建 LLM 请求体（兼容多种模型）"""
    data = {
        "model": ANT_MODEL_NAME,
        "messages": messages,
        "temperature": temperature,
        "presence_penalty": 0.0,
        "repetition_penalty": 1.0,
        "top_p": 0.95,
        "top_k": 20,
        "min_p": 0.0,
    }
    # thinking 参数仅 V4/Reasoner 系列支持
    if _is_thinking_model():
        data["chat_template_kwargs"] = {"enable_thinking": thinking}
        data["thinking"] = {"type": "enabled" if thinking else "disabled"}
    if tools:
        data["tools"] = tools
    if stream:
        data["stream"] = True
        data["stream_options"] = {"include_usage": True}
    return data

def display_usage(usage, cap):
    t = usage.get("total_tokens", 0) if usage else 0
    if t == 0 or cap <= 0:
        return
    p = min(t / cap, 1.0)
    bar = "\u2588" * int(p * 20) + "\u2591" * (20 - int(p * 20))
    print(f"\033[2mCTX [{bar}] {p:.0%}  ({t//1000}k/{cap//1000}k)\033[0m")

class ThinkRepeatError(Exception):
    pass

class RepeatSuffixChecker:
    """Rabin-Karp 滚动哈希检测 thinking 重复（照搬 AntNest）"""
    def __init__(self, min_unit_len: int, base: int = 91138233, mod: int = 10**9 + 7):
        self.min_unit_len = min_unit_len
        self.base = base
        self.mod = mod
        self.prefix_hash = [0]
        self.pow_base = [1]

    def _get_hash(self, l: int, r: int) -> int:
        return (self.prefix_hash[r] - self.prefix_hash[l] * self.pow_base[r - l]) % self.mod

    def add_char(self, ch: str) -> bool:
        self.pow_base.append((self.pow_base[-1] * self.base) % self.mod)
        new_hash = (self.prefix_hash[-1] * self.base + ord(ch)) % self.mod
        self.prefix_hash.append(new_hash)
        n = len(self.prefix_hash) - 1
        if n < 2 * self.min_unit_len or n % self.min_unit_len != 0:
            return False
        for unit_len in range(n // 2, self.min_unit_len - 1, -1):
            if self._get_hash(n - 2 * unit_len, n - unit_len) == self._get_hash(n - unit_len, n):
                return True
        return False

def _safe_stdout(text: str):
    """安全写入 stdout，忽略 GBK 编码错误（DEVNULL 重定向时仍需编码检查）"""
    try:
        sys.stdout.write(text)
        sys.stdout.flush()
    except UnicodeEncodeError:
        pass

def llm_chat_stream(messages, tools=None, temperature=0.6, thinking=True):
    """LLM 流式推理（完整照搬 AntNest）"""
    url = f"{ANT_BASE_URL}/chat/completions"
    data = _build_request_data(messages, tools, temperature, thinking, stream=True)
    body = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={**COMMON_HEADER, "Content-Type": "application/json"},
    )
    try:
        resp = urllib.request.urlopen(req, timeout=180)
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        raise Exception(f"LLM 调用失败，HTTP {e.code}: {raw[:500]}")
    except (urllib.error.URLError, socket.timeout, OSError) as e:
        raise Exception(f"LLM 网络/超时错误: {e}")

    content_parts = []
    reasoning_parts = []
    tool_calls_map = {}
    usage = None
    role = "assistant"
    is_thinking = False

    detector = RepeatSuffixChecker(min_unit_len=400)

    try:
        for raw_line in resp:
            line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")
            if not line:
                continue
            if not line.startswith("data: "):
                continue
            payload = line[6:]
            if payload.strip() == "[DONE]":
                break

            try:
                chunk = json.loads(payload)
            except json.JSONDecodeError:
                continue

            if "usage" in chunk and chunk["usage"]:
                usage = chunk["usage"]

            choices = chunk.get("choices", [])
            if not choices:
                continue

            delta = choices[0].get("delta", {})
            if not delta:
                continue

            role = delta.get("role") or role

            reasoning_content = delta.get("reasoning_content") or delta.get("reasoning") or ""
            if reasoning_content:
                if not is_thinking:
                    is_thinking = True
                    _safe_stdout("\033[2m💭 ")
                _safe_stdout(reasoning_content)
                reasoning_parts.append(reasoning_content)
                for c in reasoning_content:
                    if detector.add_char(c):
                        raise ThinkRepeatError()

            text = delta.get("content") or ""
            if text:
                if is_thinking:
                    is_thinking = False
                    _safe_stdout("\033[0m\n")
                _safe_stdout(text)
                content_parts.append(text)

            if "tool_calls" in delta and delta["tool_calls"]:
                for tc_delta in delta["tool_calls"]:
                    idx = tc_delta.get("index", 0)
                    if idx not in tool_calls_map:
                        tool_calls_map[idx] = {
                            "id": tc_delta.get("id", ""),
                            "type": "function",
                            "function": {"name": "", "arguments": ""},
                        }
                    tc_entry = tool_calls_map[idx]
                    if tc_delta.get("id"):
                        tc_entry["id"] = tc_delta["id"]
                    func_delta = tc_delta.get("function", {})
                    if func_delta.get("name"):
                        tc_entry["function"]["name"] += func_delta["name"]
                    if func_delta.get("arguments"):
                        tc_entry["function"]["arguments"] += func_delta["arguments"]

        if is_thinking:
            _safe_stdout("\033[0m\n")
    finally:
        resp.close()
        if is_thinking:
            _safe_stdout("\033[0m\n")

    full_content = "".join(content_parts)
    full_reasoning = "".join(reasoning_parts)

    # 将 LLM 思考过程和输出写入日志
    if full_reasoning:
        # 截断过长的思考过程
        reasoning_preview = full_reasoning[:500] + ("..." if len(full_reasoning) > 500 else "")
        log(f"LLM 思考: {reasoning_preview}", "蜂后推理")
    if full_content:
        content_preview = full_content[:500] + ("..." if len(full_content) > 500 else "")
        log(f"LLM 输出: {content_preview}", "蜂后推理")
    if tool_calls_map:
        tc_names = [tool_calls_map[i]["function"]["name"] for i in sorted(tool_calls_map.keys())]
        log(f"LLM 决定调用工具: {', '.join(tc_names)}", "蜂后推理")

    message = {"role": role, "content": full_content or None}
    if reasoning_parts:
        message["reasoning_content"] = full_reasoning
    else:
        message["reasoning_content"] = ""
    if tool_calls_map:
        message["tool_calls"] = [tool_calls_map[i] for i in sorted(tool_calls_map.keys())]

    if usage is None:
        usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    return message, usage


# ====================== 工具执行器 ======================
tool_executors = {
    "spawn_worker": spawn_worker,
    "leave_memory_hints": leave_memory_hints,
}

# ====================== Agent Loop ======================
def _detect_malformed_tool_call(content: str):
    """检测 LLM 是否将 function call 写成纯文本（照搬 AntNest）"""
    cl = content.lower()
    if any(x in cl for x in ["</parameter>", "</function>", "</tool_call>"]):
        return True
    if re.search(r'\{\s*"name"\s*:\s*"(?:spawn_worker|leave_memory_hints)"\s*,\s*"arguments"', cl):
        return True
    return False

def agent_single_loop():
    global COMPACT_PANIC, LAST_USAGE
    break_loop = False
    while not break_loop:
        try:
            log("agent_single_loop 轮次开始", "蜂后推理")
            sys.stdout.write("\n[*] BEEHIVE: ")
            sys.stdout.flush()
            tools = [spawn_worker_schema, memory_hints_schema] if COMPACT_PANIC else [spawn_worker_schema]

            try:
                log("调用 LLM 推理中...", "蜂后推理")
                msg, usage = llm_chat_stream(messages, tools=tools)
                log(f"LLM 推理完成 (tokens: {usage.get('total_tokens', '?') if usage else '?'})", "蜂后推理")
            except ThinkRepeatError:
                print("\n\n[!] 检测到 thinking 重复，自动中断")
                messages.append({
                    "role": "user",
                    "content": "警告：你的 thinking 中出现大量重复内容，已被擦除。请继续，不要陷入循环。",
                })
                continue

            LAST_USAGE = usage
            messages.append(msg)

            sys.stdout.write("\n\n")
            sys.stdout.flush()

            if not msg.get("tool_calls"):
                content = msg.get("content", "")
                if not content:
                    messages.append({
                        "role": "user",
                        "content": "警告：回复为空，没有输出也没有调用工具，请重新回答。",
                    })
                    continue

                if _detect_malformed_tool_call(content):
                    messages.append({
                        "role": "user",
                        "content": "警告：工具调用格式不正确，请以正确的格式调用 spawn_worker 工具。",
                    })
                    continue
                break

            for tc in msg["tool_calls"]:
                func = tc["function"]
                name = func["name"]
                try:
                    args = json.loads(func["arguments"])
                except json.JSONDecodeError:
                    args = {}

                print(f"===> {name}")
                for k, v in args.items():
                    print(f"  {k}: {v}")
                print()

                start_time = time.time()
                log(f"工具调用: {name}({json.dumps(args, ensure_ascii=False)[:200]})", "蜂后操作")

                try:
                    result = tool_executors[name](**args)
                except KeyboardInterrupt:
                    print("\n工具调用已中断")
                    result = "用户中止该工具运行"
                    break_loop = True
                except Exception as e:
                    result = f"工具执行异常：{str(e)}"

                elapsed = time.time() - start_time
                log(f"{name} 完成", "蜂后操作", duration=elapsed,
                    result="成功" if "error" not in str(result).lower()[:200] else "异常")

                # 输出工具结果预览
                print("<=== 工具返回：")
                preview = result[:6000] + "\n... 省略" if len(result) > 6000 else result
                lines = preview.splitlines()
                print("\n".join(lines[:30]))
                if len(lines) > 30:
                    print("\n... 省略")
                print()

                if name == "leave_memory_hints":
                    usage["total_tokens"] = 0
                else:
                    if len(result) > TOOL_RESULT_LEN:
                        half = TOOL_RESULT_LEN // 2
                        result = result[:half] + "\n…（中间省略）…\n" + result[-half:]
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "name": name,
                        "content": clean_input(result),
                    })

                if not COMPACT_PANIC and usage["total_tokens"] >= TOKEN_CAP * COMPACT_THRESH:
                    print("[!] 紧急回合，触发记忆压缩")
                    COMPACT_PANIC = True
                    for i, m in enumerate(messages):
                        messages[i] = _trim_tool_content(m)
                    messages.append({"role": "user", "content": COMPACT_PROMPT})

        except KeyboardInterrupt:
            log("agent_single_loop 用户中断", "蜂后推理")
            print("\nagent_single_loop 已中断")
            break_loop = True
            break
        except Exception as e:
            log(f"LLM 调用异常: {e}", "蜂后推理")
            print(f"LLM 调用异常：{e}")
            break


# ====================== 守卫蜂管理 ======================
_guard_proc = None

def start_guard():
    """启动守卫蜂子进程"""
    global _guard_proc
    try:
        guard_script = os.path.join(BEEHIVE_ROOT, "guard.py")
        proc = subprocess.Popen(
            [sys.executable, guard_script, str(os.getpid())],
            cwd=BEEHIVE_ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0,
        )
        _guard_proc = proc
        log(f"守卫蜂已启动 PID={proc.pid}", "系统设置")
        return proc
    except Exception as e:
        log(f"守卫蜂启动失败: {e}", "系统设置", result="失败")
        return None

def stop_guard():
    global _guard_proc
    if _guard_proc:
        try:
            _guard_proc.terminate()
            time.sleep(0.5)
            _guard_proc.kill()
        except Exception:
            pass
        _guard_proc = None

# 守卫蜂心跳更新（供 guard.py 读取）
def update_guard_heartbeat():
    hb_file = os.path.join(CLONE_POOL_DIR, "queen_heartbeat.json")
    try:
        with open(hb_file, "w", encoding="utf-8") as f:
            json.dump({
                "queen_pid": os.getpid(),
                "timestamp": datetime.now().isoformat(),
                "active_workers": len([1 for _ in os.listdir(CLONE_POOL_DIR)
                                       if _.startswith("clone_")]),
            }, f)
    except Exception:
        pass


# ====================== 主循环 ======================
def human_loop(user_ask=None):
    global messages

    if user_ask:
        print(f"\n[-] 任务: {user_ask}\n")
        messages.append({"role": "user", "content": clean_input(user_ask)})

    # 心跳线程
    def heartbeat():
        while True:
            update_guard_heartbeat()
            time.sleep(5)

    hb_thread = threading.Thread(target=heartbeat, daemon=True)
    hb_thread.start()

    while True:
        try:
            display_usage(LAST_USAGE, TOKEN_CAP)

            if user_ask:
                agent_single_loop()
                break

            print("")
            user_input = input("[-] 用户: ").strip()
            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "退出"):
                break

            messages.append({"role": "user", "content": clean_input(user_input)})
            agent_single_loop()

        except KeyboardInterrupt:
            print(f"\n{Colors.WARN}收到中断信号{Colors.RESET}")
            break
        except Exception as e:
            print(f"主循环异常：{e}")
            break

    # 清理
    stop_guard()
    log_color("蜂后已关闭", Colors.SUCCESS)


# ====================== 入口 ======================
if __name__ == "__main__":
    # 初始化目录
    os.makedirs(CLONE_POOL_DIR, exist_ok=True)
    os.makedirs(MEMORY_DIR, exist_ok=True)
    os.makedirs(SESSIONS_DIR, exist_ok=True)
    os.makedirs(LOGS_DIR, exist_ok=True)

    # 加载记忆
    knowledge = _read_knowledge()
    hints = _read_hints()

    # 构建初始消息
    messages = [
        {
            "role": "system",
            "content": SYSTEM_PROMPT.format(
                knowledge=knowledge or "无",
                hints=hints or "无",
                env_info=ENV_INFO,
            ),
        }
    ]

    print("=" * 60)
    print(f"  BeeHive 蜂后 ({ANT_MODEL_NAME}-{TOKEN_CAP//1000}k)")
    print(f"> 模式: 蜂后 (depth=0) | 最大深度: {MAX_DEPTH}")
    print(f"> 权限等级: {PERMISSION_LEVEL} | 最大工蜂: {MAX_WORKERS}")
    print(f"> API: {ANT_BASE_URL}")
    print("=" * 60)

    log(f"蜂后启动：model={ANT_MODEL_NAME}, base_url={ANT_BASE_URL}, workers={MAX_WORKERS}", "系统设置")

    # 启动守卫蜂
    start_guard()

    # 判断运行模式：有参数=单任务，无参数+有TTY=交互，无参数+无TTY=守护模式
    if len(sys.argv) > 1:
        # 单任务模式
        task = " ".join(sys.argv[1:])
        log(f"单任务模式: {task}", "系统设置")
        human_loop(task)
    elif sys.stdin.isatty():
        # 交互模式（终端直接启动）
        human_loop()
    else:
        # 守护模式（GUI 启动）：通过任务文件接收命令
        task_file = os.path.join(CLONE_POOL_DIR, "queen_task.txt")
        log("守护模式启动，等待任务文件...", "系统设置")
        print(f"[蜂后] 守护模式运行中，通过 {task_file} 接收任务（每行一个）")
        print("[蜂后] 要退出，创建空任务文件或发送 'exit' 指令")

        def heartbeat():
            while True:
                update_guard_heartbeat()
                time.sleep(5)
        hb_thread = threading.Thread(target=heartbeat, daemon=True)
        hb_thread.start()

        last_size = 0
        while True:
            try:
                if os.path.exists(task_file):
                    cur_size = os.path.getsize(task_file)
                    if cur_size > last_size:
                        with open(task_file, "r", encoding="utf-8") as f:
                            all_lines = f.readlines()
                        new_lines = all_lines[len([l for l in all_lines if l]) - 1:] if last_size > 0 else all_lines
                        for line in new_lines:
                            task = line.strip()
                            if not task:
                                continue
                            if task.lower() in ("exit", "quit", "退出"):
                                print("[蜂后] 收到退出指令")
                                stop_guard()
                                sys.exit(0)
                            log(f"收到任务: {task}", "系统设置")
                            messages.append({"role": "user", "content": clean_input(task)})
                            agent_single_loop()
                            log("agent_single_loop 完成，清空任务文件", "系统设置")
                            # 清空任务文件
                            with open(task_file, "w", encoding="utf-8") as f:
                                f.write("")
                        last_size = 0
                time.sleep(1)
            except KeyboardInterrupt:
                break
            except Exception as e:
                log(f"守护循环异常: {e}", "系统错误")
                print(f"[蜂后] 守护循环异常: {e}")
                time.sleep(5)

        stop_guard()
        log_color("蜂后已关闭", Colors.SUCCESS)
