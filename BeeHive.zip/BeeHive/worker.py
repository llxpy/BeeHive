#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工蜂 (Worker) — 克隆执行体

设计理念（继承 AntNest）：
- 工蜂是蜂后 spawn 出的独立子进程，在隔离目录中执行
- 通过环境变量接收命令，执行完毕写 result.json 并退出
- 执行即销毁——工蜂的 clone_pool 目录由蜂后 finally 清理
- 支持短命令（环境变量）和长命令（临时文件）两种传递方式
- 危险命令正则过滤，在工作目录限制内执行

运行条件：
  BEEHIVE_CLONE_MODE == "1"  — 由蜂后通过环境变量设置
"""

import os
import sys
import re
import json
import time
import subprocess
import traceback
from datetime import datetime
from pathlib import Path

# ===========================================================================
# 色定义
# ===========================================================================
class Colors:
    RESET = "\033[0m"
    WORKER = "\033[1;33m"
    ERROR = "\033[1;31m"
    SUCCESS = "\033[1;32m"

# ===========================================================================
# 危险命令过滤规则（正则黑名单）
# ===========================================================================
DANGEROUS_PATTERNS = [
    # 格式化磁盘
    (r'\bformat\s+[cdefghijklmnopqrstuvwxyz]:', "检测到格式化磁盘命令"),
    # 强制删除系统文件
    (r'\bdel\s+/[fsq]\s+[cdef]:\\', "检测到强制删除系统文件"),
    # rm -rf 根目录
    (r'\brm\s+-rf\s+/', "检测到删除根目录命令"),
    # rmdir 系统目录
    (r'\brmdir\s+/[sq]\s+[cdef]:\\', "检测到删除系统目录命令"),
    # 关机/重启
    (r'\bshutdown\s+/[rps]', "检测到关机/重启命令"),
    # deltree
    (r'\bdeltree\b', "检测到 deltree 命令"),
    # diskpart (磁盘分区工具)
    (r'\bdiskpart\b', "检测到磁盘分区命令"),
    # wmic delete (危险 WMI 操作)
    (r'\bwmic\b.*\bdelete\b', "检测到 WMI 删除操作"),
    # reg delete (注册表删除 HKLM)
    (r'\breg\s+delete\s+HKLM', "检测到删除 HKLM 注册表"),
    # cipher /w (覆写空闲空间)
    (r'\bcipher\s+/w:', "检测到磁盘覆写命令"),
    # bcdedit (启动配置修改)
    (r'\bbcdedit\s+/delete', "检测到启动配置删除"),
    # takeown + icacls (权限夺取)
    (r'\btakeown\b.*C:\\Windows', "检测到系统文件权限夺取"),
    # net user 删除管理员
    (r'\bnet\s+user\s+administrator\s+/delete', "检测到删除管理员账户"),
]

# ===========================================================================
# 权限工作目录白名单
# ===========================================================================
def get_allowed_path(permission_level: str) -> str:
    """
    根据权限等级返回工作目录白名单根路径
    L0: 只读，不允许任何写入
    L1: 当前 clone 目录
    L2: 用户目录
    L3+: C:\
    """
    if permission_level in ("L0",):
        return None  # 不允许写入
    elif permission_level == "L1":
        return os.getcwd()  # clone 目录
    elif permission_level == "L2":
        return os.environ.get("USERPROFILE", os.path.expanduser("~"))
    else:  # L3, L4
        return "C:\\"

# ===========================================================================
# 日志写入
# ===========================================================================
def write_worker_log(worker_id: str, message: str):
    """写工蜂日志（简化版——直接写入 clone 目录的 worker.log）"""
    try:
        log_path = os.path.join(os.getcwd(), "worker.log")
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] [{worker_id}] {message}\n")
    except Exception:
        pass  # 日志失败不影响主流程

# ===========================================================================
# 主执行逻辑
# ===========================================================================
def main():
    """工蜂主函数——检查环境变量，执行命令，写结果，退出"""

    # ---------------------------------------------------------------
    # Step 1: 验证 clone 模式
    # ---------------------------------------------------------------
    if os.environ.get("BEEHIVE_CLONE_MODE") != "1":
        # 正常导入模式（作为库被加载），不做任何事
        print(f"{Colors.WORKER}工蜂代码已加载，等待蜂后调度...{Colors.RESET}")
        return False

    # ---------------------------------------------------------------
    # Step 2: 读取环境变量
    # ---------------------------------------------------------------
    worker_id = os.environ.get("BEEHIVE_WORKER_ID", f"worker_{os.getpid()}")
    command = os.environ.get("BEEHIVE_COMMAND", "")
    command_file = os.environ.get("BEEHIVE_COMMAND_FILE", "")
    timeout_str = os.environ.get("BEEHIVE_TIMEOUT", "300")
    permission_level = os.environ.get("BEEHIVE_PERMISSION_LEVEL", "L2")
    depth_str = os.environ.get("BEEHIVE_DEPTH", "1")
    result_file = os.environ.get("BEEHIVE_RESULT_FILE", "result.json")
    label = os.environ.get("BEEHIVE_LABEL", worker_id)

    # 转换类型
    try:
        timeout = int(timeout_str)
    except ValueError:
        timeout = 300

    start_time = time.time()

    print(f"{Colors.WORKER}[工蜂 {worker_id}] 启动 — 深度={depth_str} — 权限={permission_level}{Colors.RESET}")
    write_worker_log(worker_id, f"启动: 深度={depth_str}, 权限={permission_level}, 超时={timeout}s")

    # ---------------------------------------------------------------
    # Step 3: 读取命令（环境变量 → 临时文件）
    # ---------------------------------------------------------------
    if not command and command_file:
        # 从临时文件读取长命令
        try:
            with open(command_file, "r", encoding="utf-8") as f:
                command = f.read().strip()
            write_worker_log(worker_id, f"从文件读取命令: {command_file} ({len(command)} 字符)")
        except Exception as e:
            result = {
                "status": "error",
                "worker_id": worker_id,
                "label": label,
                "exit_code": -1,
                "stdout": "",
                "stderr": f"无法读取命令文件: {e}",
                "duration": time.time() - start_time,
                "error": str(e),
            }
            _write_result(result_file, result)
            sys.exit(1)

    if not command:
        result = {
            "status": "error",
            "worker_id": worker_id,
            "label": label,
            "exit_code": -1,
            "stdout": "",
            "stderr": "未收到任何命令（BEEHIVE_COMMAND 和 BEEHIVE_COMMAND_FILE 均为空）",
            "duration": time.time() - start_time,
            "error": "empty_command",
        }
        _write_result(result_file, result)
        sys.exit(1)

    command = command.strip()
    print(f"{Colors.WORKER}[工蜂 {worker_id}] 命令: {command[:200]}{'...' if len(command) > 200 else ''}{Colors.RESET}")
    write_worker_log(worker_id, f"执行命令: {command[:500]}")

    # ---------------------------------------------------------------
    # Step 4: 危险命令过滤
    # ---------------------------------------------------------------
    for pattern, reason in DANGEROUS_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            print(f"{Colors.ERROR}[工蜂 {worker_id}] 危险命令已拦截: {reason}{Colors.RESET}")
            write_worker_log(worker_id, f"危险命令拦截: {reason}")

            result = {
                "status": "blocked",
                "worker_id": worker_id,
                "label": label,
                "exit_code": -1,
                "stdout": "",
                "stderr": f"危险命令已拦截: {reason}",
                "duration": time.time() - start_time,
                "blocked_reason": reason,
            }
            _write_result(result_file, result)
            sys.exit(0)

    # ---------------------------------------------------------------
    # Step 5: 工作目录检查
    # ---------------------------------------------------------------
    work_dir = os.getcwd()
    allowed_root = get_allowed_path(permission_level)

    if allowed_root is None:
        # L0 不允许任何写入操作
        result = {
            "status": "blocked",
            "worker_id": worker_id,
            "label": label,
            "exit_code": -1,
            "stdout": "",
            "stderr": f"权限等级 {permission_level} 不允许执行写操作",
            "duration": time.time() - start_time,
            "blocked_reason": "permission_denied",
        }
        _write_result(result_file, result)
        sys.exit(0)

    if allowed_root != "C:\\":
        # 检查当前工作目录是否在白名单内
        work_dir_norm = os.path.normpath(work_dir).lower()
        allowed_norm = os.path.normpath(allowed_root).lower()
        if not work_dir_norm.startswith(allowed_norm):
            print(f"{Colors.ERROR}[工蜂 {worker_id}] 工作目录不在白名单内: {work_dir}{Colors.RESET}")
            result = {
                "status": "blocked",
                "worker_id": worker_id,
                "label": label,
                "exit_code": -1,
                "stdout": "",
                "stderr": f"工作目录 {work_dir} 不在权限白名单内 ({permission_level})",
                "duration": time.time() - start_time,
                "blocked_reason": "path_not_allowed",
            }
            _write_result(result_file, result)
            sys.exit(0)

    # ---------------------------------------------------------------
    # Step 5.5: 内联 Python 代码 → 脚本文件（避免 cmd /c 引号嵌套破坏）
    # ---------------------------------------------------------------
    # 匹配 python -c "..." / python3 -c "..."，可能是纯命令或复合命令前缀
    inline_py = re.search(
        r'(?:^|\s&&\s|\s\|\|\s|\b)(?:python(?:3)?)\s+-c\s+"((?:[^"\\]|\\.)*)"',
        command
    )
    if not inline_py:
        # 再试单引号版本
        inline_py = re.search(
            r"(?:^|\s&&\s|\s\|\|\s|\b)(?:python(?:3)?)\s+-c\s+'((?:[^'\\]|\\.)*)'",
            command
        )
    if inline_py:
        code_body = inline_py.group(1)
        # 还原转义
        code_body = code_body.replace('\\"', '"').replace("\\\'", "'")
        code_body = code_body.replace('\\\\', '\\')
        script_path = os.path.join(work_dir, f"worker_script_{worker_id}.py")
        try:
            with open(script_path, "w", encoding="utf-8") as f:
                f.write(code_body)
            # 替换原命令中的 python -c "..." 为 python "script.py"
            old_py_part = inline_py.group(0).lstrip()
            command = command.replace(old_py_part, f'python "{script_path}"', 1)
            write_worker_log(worker_id, f"内联代码已写入脚本: {script_path}")
        except Exception as e:
            write_worker_log(worker_id, f"脚本写入失败: {e}")

    # ---------------------------------------------------------------
    # Step 6: 执行命令
    # ---------------------------------------------------------------
    try:
        # 使用 subprocess 执行命令
        # Windows: cmd /c 包装确保兼容性
        if sys.platform == "win32":
            proc = subprocess.Popen(
                ["cmd", "/c", command],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=work_dir,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
        else:
            proc = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=work_dir,
                text=True,
                encoding="utf-8",
                errors="replace",
            )

        try:
            stdout, stderr = proc.communicate(timeout=timeout)
            exit_code = proc.returncode
        except subprocess.TimeoutExpired:
            # 超时处理
            proc.kill()
            try:
                stdout, stderr = proc.communicate(timeout=5)
            except Exception:
                stdout, stderr = "", "命令执行超时且无法获取输出"
            exit_code = -1
            stderr = f"(超时 {timeout}s) {stderr or ''}"

        duration = time.time() - start_time

        # 截断输出（防止超大输出）
        max_output = 50000  # 50KB 上限
        if stdout and len(stdout) > max_output:
            stdout = stdout[:max_output] + f"\n... (截断，原始 {len(stdout)} 字符)"
        if stderr and len(stderr) > max_output:
            stderr = stderr[:max_output] + f"\n... (截断，原始 {len(stderr)} 字符)"

        status = "success" if exit_code == 0 else "error"

        result = {
            "status": status,
            "worker_id": worker_id,
            "label": label,
            "exit_code": exit_code,
            "stdout": stdout or "",
            "stderr": stderr or "",
            "duration": round(duration, 3),
            "depth": int(depth_str),
        }

        print(f"{Colors.SUCCESS if status == 'success' else Colors.ERROR}[工蜂 {worker_id}] "
              f"{'完成' if status == 'success' else '失败'} — 耗时 {duration:.2f}s — "
              f"exit_code={exit_code}{Colors.RESET}")
        write_worker_log(
            worker_id,
            f"{'完成' if status == 'success' else '失败'}: "
            f"exit_code={exit_code}, 耗时={duration:.3f}s, "
            f"stdout={len(stdout or '')}chars, stderr={len(stderr or '')}chars"
        )

    except Exception as e:
        duration = time.time() - start_time
        result = {
            "status": "error",
            "worker_id": worker_id,
            "label": label,
            "exit_code": -1,
            "stdout": "",
            "stderr": traceback.format_exc(),
            "duration": round(duration, 3),
            "error": str(e),
            "depth": int(depth_str),
        }

        print(f"{Colors.ERROR}[工蜂 {worker_id}] 异常: {e}{Colors.RESET}")
        write_worker_log(worker_id, f"执行异常: {e}")

    # ---------------------------------------------------------------
    # Step 7: 写入结果文件
    # ---------------------------------------------------------------
    _write_result(result_file, result)

    # ---------------------------------------------------------------
    # Step 8: 工蜂间通信——如需要，写入 .bee_dance.json
    # ---------------------------------------------------------------
    dance_file = os.environ.get("BEEHIVE_DANCE_FILE", "")
    if dance_file and result.get("status") == "success":
        _write_dance_data(dance_file, worker_id, result)

    # ---------------------------------------------------------------
    # Step 9: 干净退出
    # ---------------------------------------------------------------
    write_worker_log(worker_id, f"退出: status={result['status']}")
    print(f"{Colors.WORKER}[工蜂 {worker_id}] 退出{Colors.RESET}")
    sys.exit(0 if result["status"] == "success" else 1)


def _write_result(result_file: str, result: dict):
    """写入 result.json"""
    try:
        # 如果 result_file 是相对路径，基于当前工作目录
        if not os.path.isabs(result_file):
            result_file = os.path.join(os.getcwd(), result_file)
        with open(result_file, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
    except Exception as e:
        # 最后的兜底——写入 stderr
        sys.stderr.write(f"无法写入结果文件 {result_file}: {e}\n")


def _write_dance_data(dance_file: str, worker_id: str, result: dict):
    """
    写入蜂舞协议数据（工蜂间通信）
    多只工蜂并行执行时，可共享中间结果
    """
    try:
        if not os.path.isabs(dance_file):
            dance_file = os.path.join(os.getcwd(), dance_file)

        # 读取已有数据（如果存在）
        existing = {}
        if os.path.exists(dance_file):
            try:
                with open(dance_file, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            except Exception:
                pass

        # 添加本工蜂的结果
        existing[worker_id] = {
            "timestamp": datetime.now().isoformat(),
            "status": result.get("status"),
            "stdout_preview": (result.get("stdout", "") or "")[:500],
        }

        # 写回文件（原子写入：先写临时文件再重命名）
        tmp_file = dance_file + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
        os.replace(tmp_file, dance_file)

    except Exception:
        pass  # 蜂舞通信失败不影响主流程


# ===========================================================================
# 入口
# ===========================================================================
if __name__ == "__main__":
    main()

