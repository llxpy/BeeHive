#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BeeHive（蜂巢）全自动桌面接管系统 — 入口文件

功能：
- 使用 tkinter 构建 GUI 权限授权界面
- 启动时弹出窗口，展示 L0-L4 五级权限说明
- 用户勾选后生成 signed_permission.json
- 授权通过后启动蜂后（queen.py），GUI 转为系统托盘监控界面
- 显示蜂后状态、活跃工蜂数、守卫蜂状态
- 支持命令行模式：python beehive.py --auto 跳过 GUI
- 启动前检查 config.json 和 API Key
- 支持单任务模式：python beehive.py --task "任务描述"

运行方式：
    python beehive.py                 # GUI 模式
    python beehive.py --auto          # 命令行模式（跳过 GUI）
    python beehive.py --auto --level L3  # 命令行模式 + 指定权限
    python beehive.py --task "整理桌面"  # 单任务模式
"""

import os
import sys
import json
import time
import subprocess
import threading
import signal
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# 项目根目录
# ---------------------------------------------------------------------------
BEEHIVE_ROOT = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BEEHIVE_ROOT, "local_config.json")
PERMISSION_FILE = os.path.join(BEEHIVE_ROOT, "signed_permission.json")

# ---------------------------------------------------------------------------
# 颜色定义
# ---------------------------------------------------------------------------
class Colors:
    RESET = "\033[0m"
    HIVE = "\033[1;36m"
    WARN = "\033[1;33m"
    ERROR = "\033[1;31m"
    SUCCESS = "\033[1;32m"

# ---------------------------------------------------------------------------
# 权限等级说明
# ---------------------------------------------------------------------------
PERMISSION_INFO = [
    ("L0 - 只读", "只能读取文件和查询系统信息，不能修改任何内容。适合：安全审计、信息查询"),
    ("L1 - 沙箱", "在 BeeHive 专属沙箱目录内可任意操作，不可访问外部文件。适合：测试、实验"),
    ("L2 - 用户空间", "可在桌面/文档/下载等用户目录读写文件。适合：日常文件管理、文档处理"),
    ("L3 - 系统级", "全磁盘访问 + 进程管理 + 注册表读写（HKCU）。适合：系统优化、程序管理"),
    ("L4 - 完全接管", "关机/重启/网络配置/驱动安装/服务管理/注册表（HKLM）。适合：完全自动化"),
]

# ---------------------------------------------------------------------------
# 配置检查
# ---------------------------------------------------------------------------
def check_prerequisites():
    """
    启动前检查 config.json 和 API Key
    返回：（bool, str）— (是否通过, 错误信息)
    """
    if not os.path.exists(CONFIG_PATH):
        return False, f"配置文件不存在: {CONFIG_PATH}"

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            config = json.load(f)
    except json.JSONDecodeError as e:
        return False, f"配置文件格式错误: {e}"

    api_key = config.get("api", {}).get("api_key", "")
    if not api_key:
        return False, "API Key 未配置。请在 config.json 中填写 api.api_key"

    return True, "检查通过"

# ---------------------------------------------------------------------------
# 权限文件管理
# ---------------------------------------------------------------------------
def create_permission_file(level: str):
    """生成签名权限文件"""
    try:
        sys.path.insert(0, BEEHIVE_ROOT)
        import permission
        data = permission.create_signed_permission(level)
        with open(PERMISSION_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True, data
    except Exception as e:
        return False, str(e)

# ---------------------------------------------------------------------------
# 蜂后启动
# ---------------------------------------------------------------------------
def start_queen(level: str = "L2"):
    """
    启动蜂后进程
    返回：subprocess.Popen 对象
    """
    queen_path = os.path.join(BEEHIVE_ROOT, "queen.py")

    # 设置环境变量覆盖权限等级
    env = os.environ.copy()
    env["BEEHIVE_PERMISSION_LEVEL"] = level
    env["PYTHONIOENCODING"] = "utf-8"

    proc = subprocess.Popen(
        [sys.executable, queen_path],
        cwd=BEEHIVE_ROOT,
        env=env,
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        text=True,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )
    return proc

# ---------------------------------------------------------------------------
# GUI：权限授权界面
# ---------------------------------------------------------------------------
class PermissionWindow:
    """权限授权 GUI 窗口"""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("BeeHive 蜂巢 — 权限授权")
        self.root.geometry("640x600")
        self.root.resizable(False, False)

        # 窗口居中
        self.root.update_idletasks()
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - 640) // 2
        y = (screen_height - 600) // 2
        self.root.geometry(f"640x600+{x}+{y}")

        # 禁止关闭按钮直接关闭（必须走授权流程）
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # 变量
        self.selected_level = tk.StringVar(value="L2")
        self.approved = False
        self.queen_proc = None

        self._build_ui()

    def _build_ui(self):
        """构建界面"""
        # 标题（使用 frame 作为 banner）
        banner = tk.Frame(self.root, bg="#1a1a2e", height=70)
        banner.pack(fill=tk.X)
        banner.pack_propagate(False)

        title = tk.Label(
            banner,
            text="BeeHive 蜂巢",
            font=("Microsoft YaHei", 22, "bold"),
            fg="#e94560",
            bg="#1a1a2e",
        )
        title.pack(pady=5)
        subtitle = tk.Label(
            banner,
            text="全自动桌面接管系统 — 权限授权",
            font=("Microsoft YaHei", 10),
            fg="#8888aa",
            bg="#1a1a2e",
        )
        subtitle.pack()

        # 主内容区
        main = tk.Frame(self.root, bg="#16213e")
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 说明文字
        desc = tk.Label(
            main,
            text="请选择授予 BeeHive 的权限等级。\n权限越高，BeeHive 能为您完成的操作越多。",
            font=("Microsoft YaHei", 10),
            fg="#ccccdd",
            bg="#16213e",
            justify=tk.LEFT,
        )
        desc.pack(anchor=tk.W, pady=(5, 10))

        # 权限等级选项
        for level_name, description in PERMISSION_INFO:
            frame = tk.Frame(main, bg="#0f3460", bd=1, relief=tk.RAISED)
            frame.pack(fill=tk.X, padx=5, pady=4)

            # Radio 按钮
            rb = tk.Radiobutton(
                frame,
                text=level_name,
                variable=self.selected_level,
                value=level_name.split(" ")[0],  # 取 L0/L1/L2...
                font=("Consolas", 11, "bold"),
                fg="#e94560",
                bg="#0f3460",
                selectcolor="#0f3460",
                activebackground="#0f3460",
                activeforeground="#ff6b6b",
            )
            rb.pack(anchor=tk.W, padx=8, pady=(5, 0))

            # 说明
            desc_label = tk.Label(
                frame,
                text=description,
                font=("Microsoft YaHei", 9),
                fg="#aabbcc",
                bg="#0f3460",
                wraplength=560,
                justify=tk.LEFT,
            )
            desc_label.pack(anchor=tk.W, padx=28, pady=(0, 8))

        # 底部按钮区
        bottom = tk.Frame(self.root, bg="#1a1a2e", height=50)
        bottom.pack(fill=tk.X)

        # 确认按钮
        confirm_btn = tk.Button(
            bottom,
            text="确认授权并启动",
            font=("Microsoft YaHei", 11, "bold"),
            bg="#e94560",
            fg="#ffffff",
            activebackground="#ff6b6b",
            activeforeground="#ffffff",
            relief=tk.FLAT,
            padx=20,
            pady=8,
            cursor="hand2",
            command=self.on_confirm,
        )
        confirm_btn.pack(side=tk.RIGHT, padx=15, pady=8)

        # 取消按钮
        cancel_btn = tk.Button(
            bottom,
            text="取消",
            font=("Microsoft YaHei", 10),
            bg="#333355",
            fg="#8888aa",
            activebackground="#444466",
            activeforeground="#aaaacc",
            relief=tk.FLAT,
            padx=15,
            pady=8,
            cursor="hand2",
            command=self.on_close,
        )
        cancel_btn.pack(side=tk.RIGHT, padx=5, pady=8)

    def on_confirm(self):
        """确认授权"""
        level = self.selected_level.get()

        # 生成权限文件
        success, result = create_permission_file(level)
        if not success:
            messagebox.showerror("错误", f"权限文件生成失败：{result}")
            return

        self.approved = True
        self.selected_level_str = level

        # 关闭授权窗口
        self.root.destroy()

    def on_close(self):
        """关闭窗口"""
        if messagebox.askokcancel("退出", "确定要退出 BeeHive 吗？"):
            self.approved = False
            self.root.destroy()

# ---------------------------------------------------------------------------
# GUI：系统托盘监控界面
# ---------------------------------------------------------------------------
class MonitorWindow:
    """蜂后状态监控 GUI"""

    def __init__(self, root: tk.Tk, queen_proc: subprocess.Popen, level: str):
        self.root = root
        self.queen_proc = queen_proc
        self.level = level
        self.running = True
        self.start_time = time.time()

        self.root.title("BeeHive 蜂巢 — 运行监控")
        self.root.geometry("500x480")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # 居中
        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x = (sw - 500) // 2
        y = (sh - 480) // 2
        self.root.geometry(f"500x480+{x}+{y}")

        self._build_ui()

        # 启动状态刷新
        self._start_refresh()

    def _build_ui(self):
        """构建监控界面"""
        # Banner
        banner = tk.Frame(self.root, bg="#1a1a2e", height=50)
        banner.pack(fill=tk.X)
        banner.pack_propagate(False)
        title = tk.Label(banner, text="BeeHive 蜂巢 — 运行中",
                         font=("Microsoft YaHei", 14, "bold"), fg="#e94560", bg="#1a1a2e")
        title.pack(pady=10)

        # 主内容
        main = tk.Frame(self.root, bg="#16213e")
        main.pack(fill=tk.BOTH, expand=True, padx=15, pady=10)

        # 状态标签
        self.status_var = tk.StringVar(value="蜂后: 运行中")
        tk.Label(main, textvariable=self.status_var, font=("Microsoft YaHei", 10),
                 fg="#4ecca3", bg="#16213e").pack(anchor=tk.W, pady=3)

        # 详情（使用变量动态更新）
        self.uptime_var = tk.StringVar(value="运行时间: 00:00:00")
        tk.Label(main, textvariable=self.uptime_var, font=("Consolas", 10),
                 fg="#ccccdd", bg="#16213e").pack(anchor=tk.W, pady=2)

        self.workers_var = tk.StringVar(value="活跃工蜂: 0")
        tk.Label(main, textvariable=self.workers_var, font=("Consolas", 10),
                 fg="#ccccdd", bg="#16213e").pack(anchor=tk.W, pady=2)

        self.guard_var = tk.StringVar(value="守卫蜂: 运行中")
        tk.Label(main, textvariable=self.guard_var, font=("Consolas", 10),
                 fg="#ccccdd", bg="#16213e").pack(anchor=tk.W, pady=2)

        self.permission_var = tk.StringVar(value=f"权限等级: {self.level}")
        tk.Label(main, textvariable=self.permission_var, font=("Consolas", 10),
                 fg="#ccccdd", bg="#16213e").pack(anchor=tk.W, pady=2)

        # 分隔线
        ttk.Separator(main, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=10)

        # 日志输出
        tk.Label(main, text="系统日志:", font=("Microsoft YaHei", 10, "bold"),
                 fg="#e94560", bg="#16213e").pack(anchor=tk.W)

        self.log_text = scrolledtext.ScrolledText(
            main,
            height=8,
            font=("Consolas", 9),
            bg="#0f3460",
            fg="#aabbcc",
            insertbackground="#aabbcc",
            wrap=tk.WORD,
            state=tk.DISABLED,
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, pady=(3, 0))

        # 指令输入区
        input_frame = tk.Frame(self.root, bg="#16213e")
        input_frame.pack(fill=tk.X, padx=15, pady=(5, 0))

        self.command_entry = tk.Entry(
            input_frame,
            font=("Microsoft YaHei", 10),
            bg="#0f3460",
            fg="#ffffff",
            insertbackground="#ffffff",
            relief=tk.SUNKEN,
        )
        self.command_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=3)
        self.command_entry.bind("<Return>", lambda e: self.send_command())
        self.command_entry.focus_set()

        send_btn = tk.Button(
            input_frame,
            text="发送指令",
            font=("Microsoft YaHei", 10),
            bg="#e94560",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=10,
            pady=3,
            activebackground="#ff6b6b",
            cursor="hand2",
            command=self.send_command,
        )
        send_btn.pack(side=tk.RIGHT, padx=(8, 0))

        # 底部按钮
        bottom = tk.Frame(self.root, bg="#1a1a2e", height=40)
        bottom.pack(fill=tk.X)

        shutdown_btn = tk.Button(
            bottom, text="关闭 BeeHive", font=("Microsoft YaHei", 10),
            bg="#e94560", fg="#ffffff", relief=tk.FLAT, padx=10, pady=5,
            activebackground="#ff4444", cursor="hand2", command=self.on_shutdown,
        )
        shutdown_btn.pack(side=tk.RIGHT, padx=15, pady=5)

    def _start_refresh(self):
        """启动定时刷新"""
        def refresh():
            last_log_check = 0
            while self.running and self.root.winfo_exists():
                try:
                    # 更新运行时间
                    elapsed = time.time() - self.start_time
                    h = int(elapsed // 3600)
                    m = int((elapsed % 3600) // 60)
                    s = int(elapsed % 60)
                    self.uptime_var.set(f"运行时间: {h:02d}:{m:02d}:{s:02d}")

                    # 检查守卫蜂心跳
                    heartbeat_file = os.path.join(BEEHIVE_ROOT, "clone_pool", "guard_heartbeat.json")
                    if os.path.exists(heartbeat_file):
                        try:
                            with open(heartbeat_file, "r", encoding="utf-8") as f:
                                hb = json.load(f)
                            age = time.time() - datetime.fromisoformat(hb.get("timestamp", "2000-01-01T00:00:00")).timestamp()
                            if age < 30:
                                self.guard_var.set(f"守卫蜂: 运行中 (PID={hb.get('guard_pid', '?')})")
                                self.workers_var.set(f"活跃工蜂: {hb.get('active_workers', 0)}")
                            else:
                                self.guard_var.set("守卫蜂: 心跳超时")
                        except Exception:
                            self.guard_var.set("守卫蜂: 无响应")

                    # 更新日志区域
                    log_dir = os.path.join(BEEHIVE_ROOT, "logs", datetime.now().strftime("%Y-%m-%d"))
                    queen_log = os.path.join(log_dir, "queen.log")
                    if os.path.exists(queen_log):
                        mtime = os.path.getmtime(queen_log)
                        if mtime > last_log_check:
                            last_log_check = mtime
                            try:
                                with open(queen_log, "r", encoding="utf-8") as f:
                                    lines = f.readlines()
                                # 只显示最后 15 条
                                recent = lines[-15:]
                                self.log_text.configure(state=tk.NORMAL)
                                self.log_text.delete(1.0, tk.END)
                                self.log_text.insert(tk.END, "".join(recent))
                                self.log_text.see(tk.END)
                                self.log_text.configure(state=tk.DISABLED)
                            except Exception:
                                pass

                except Exception:
                    pass

                time.sleep(1)

        t = threading.Thread(target=refresh, daemon=True)
        t.start()

    def send_command(self):
        """发送指令给蜂后（写入任务文件）"""
        command = self.command_entry.get().strip()
        if not command:
            return

        # 显示在日志中
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        log_line = f"[{timestamp}] [用户指令] {command}\n"
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, log_line)
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)

        # 写入任务文件，蜂后守护模式轮询读取
        task_file = os.path.join(BEEHIVE_ROOT, "clone_pool", "queen_task.txt")
        try:
            os.makedirs(os.path.dirname(task_file), exist_ok=True)
            with open(task_file, "a", encoding="utf-8") as f:
                f.write(command + "\n")
        except Exception as e:
            self.log_text.configure(state=tk.NORMAL)
            self.log_text.insert(tk.END, f"[错误] 无法写入任务文件: {e}\n")
            self.log_text.see(tk.END)
            self.log_text.configure(state=tk.DISABLED)

        # 清空输入框
        self.command_entry.delete(0, tk.END)

    def on_shutdown(self):
        """关闭 BeeHive"""
        if messagebox.askokcancel("确认关闭", "确定要关闭 BeeHive 吗？所有工蜂将被终止。"):
            self.running = False
            # 终止蜂后
            if self.queen_proc:
                try:
                    self.queen_proc.terminate()
                    time.sleep(0.5)
                    self.queen_proc.kill()
                except Exception:
                    pass
            self.root.destroy()

    def on_close(self):
        """窗口关闭事件——最小化到托盘（简化版：直接确认关闭）"""
        self.on_shutdown()

# ---------------------------------------------------------------------------
# 命令行模式
# ---------------------------------------------------------------------------
def run_auto_mode(level: str = "L2"):
    """命令行自动模式"""
    print(f"{Colors.HIVE}=== BeeHive 自动模式 (权限: {level}) ==={Colors.RESET}")

    # 生成权限文件
    success, data = create_permission_file(level)
    if not success:
        print(f"{Colors.ERROR}权限文件生成失败: {data}{Colors.RESET}")
        return 1

    print(f"{Colors.SUCCESS}权限文件已签名: {PERMISSION_FILE}{Colors.RESET}")

    # 启动蜂后
    print(f"{Colors.HIVE}启动蜂后...{Colors.RESET}")
    proc = start_queen(level)

    # 输出蜂后日志到控制台
    try:
        while True:
            line = proc.stdout.readline()
            if line:
                print(line.rstrip())
            if proc.poll() is not None:
                break
    except KeyboardInterrupt:
        print(f"\n{Colors.WARN}收到中断信号，关闭蜂后...{Colors.RESET}")
        proc.terminate()
        time.sleep(0.5)
        proc.kill()

    return proc.returncode or 0

def run_task_mode(task: str, level: str = "L2"):
    """单任务模式"""
    print(f"{Colors.HIVE}=== BeeHive 单任务模式 ==={Colors.RESET}")
    print(f"任务: {task}")

    # 生成权限文件
    success, data = create_permission_file(level)
    if not success:
        print(f"{Colors.ERROR}权限文件生成失败: {data}{Colors.RESET}")
        return 1

    # 启动蜂后（带任务参数）
    queen_path = os.path.join(BEEHIVE_ROOT, "queen.py")
    env = os.environ.copy()
    env["BEEHIVE_PERMISSION_LEVEL"] = level
    env["PYTHONIOENCODING"] = "utf-8"

    proc = subprocess.Popen(
        [sys.executable, queen_path, task],
        cwd=BEEHIVE_ROOT,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=="win32" else 0,
    )

    try:
        while True:
            line = proc.stdout.readline()
            if line:
                print(line.rstrip())
            if proc.poll() is not None:
                break
    except KeyboardInterrupt:
        proc.terminate()

    return proc.returncode or 0

# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------
def main():
    """主入口函数"""

    # 解析命令行参数
    if "--auto" in sys.argv:
        # 命令行自动模式
        level = "L2"
        if "--level" in sys.argv:
            idx = sys.argv.index("--level")
            if idx + 1 < len(sys.argv):
                level = sys.argv[idx + 1]
        sys.exit(run_auto_mode(level))

    if "--task" in sys.argv:
        # 单任务模式
        task_idx = sys.argv.index("--task")
        task = ""
        level = "L2"
        for i, arg in enumerate(sys.argv):
            if arg == "--task" and i + 1 < len(sys.argv):
                task = sys.argv[i + 1]
            if arg == "--level" and i + 1 < len(sys.argv):
                level = sys.argv[i + 1]
        if not task:
            print(f"{Colors.ERROR}错误：--task 后需要指定任务描述{Colors.RESET}")
            sys.exit(1)
        sys.exit(run_task_mode(task, level))

    # 前置检查
    ok, msg = check_prerequisites()
    if not ok:
        print(f"{Colors.ERROR}{msg}{Colors.RESET}")
        if "--auto" not in sys.argv:
            # GUI 模式下也显示错误
            messagebox.showerror("启动失败", msg)
        sys.exit(1)

    # --- GUI 模式 ---
    # Phase 1: 权限授权
    root1 = tk.Tk()
    perm_window = PermissionWindow(root1)
    root1.mainloop()

    if not perm_window.approved:
        print(f"{Colors.WARN}用户取消授权，退出{Colors.RESET}")
        sys.exit(0)

    level = perm_window.selected_level_str
    print(f"{Colors.SUCCESS}权限授权: {level}{Colors.RESET}")

    # 启动蜂后
    print(f"{Colors.HIVE}启动蜂后...{Colors.RESET}")
    queen_proc = start_queen(level)

    # Phase 2: 监控界面
    root2 = tk.Tk()
    monitor = MonitorWindow(root2, queen_proc, level)
    root2.mainloop()

    print(f"{Colors.HIVE}BeeHive 已关闭{Colors.RESET}")

if __name__ == "__main__":
    main()
